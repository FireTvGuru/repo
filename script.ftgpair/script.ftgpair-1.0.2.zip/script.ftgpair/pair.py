############################################################################
#                             /T /I                                        #
#                              / |/ | .-~/                                 #
#                          T\ Y  I  |/  /  _                               #
#         /T               | \I  |  I  Y.-~/                               #
#        I l   /I       T\ |  |  l  |  T  /                                #
#     T\ |  \ Y l  /T   | \I  l   \ `  l Y       If your going to copy     #
# __  | \l   \l  \I l __l  l   \   `  _. |       this addon just           #
# \ ~-l  `\   `\  \  \ ~\  \   `. .-~   |        give credit!              #
#  \   ~-. "-.  `  \  ^._ ^. "-.  /  \   |                                 #
#.--~-._  ~-  `  _  ~-_.-"-." ._ /._ ." ./                                 #
# >--.  ~-.   ._  ~>-"    "\   7   7   ]                                   #
#^.___~"--._    ~-{  .-~ .  `\ Y . /    |                                  #
# <__ ~"-.  ~       /_/   \   \I  Y   : |                                  #
#   ^-.__           ~(_/   \   >._:   | l______                            #
#       ^--.,___.-~"  /_/   !  `-.~"--l_ /     ~"-.                        #
#              (_/ .  ~(   /'     "~"--,Y   -=b-. _)                       #
#               (_/ .  \  :           / l      c"~o \                      #
#                \ /    `.    .     .^   \_.-~"~--.  )                     #
#                 (_/ .   `  /     /       !       )/                      #
#                  / / _.   '.   .':      /        '                       #
#                  ~(_/ .   /    _  `  .-<_                                #
#                    /_/ . ' .-~" `.  / \  \          ,z=.                 #
#                    ~( /   '  :   | K   "-.~-.______//                    #
#                      "-,.    l   I/ \_    __{--->._(==.                  #
#                       //(     \  <    ~"~"     //                        #
#                      /' /\     \  \     ,v=.  ((     Fire TV Guru        #
#                    .^. / /\     "  }__ //===-  `    PyXBMCt LaYOUt       #
#                   / / ' '  "-.,__ {---(==-                               #
#                 .^ '       :  T  ~"   ll                                 #
#                / .  .  . : | :!        \                                 #
#               (_/  /   | | j-"          ~^                               #
#                 ~-<_(_.^-~"                                              #
#                                                                          #
#                  Copyright (C) One of those Years....                    #
#                                                                          #
#  This program is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by    #
#  the Free Software Foundation, either version 3 of the License, or       #
#  (at your option) any later version.                                     #
#                                                                          #
#  This program is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of          #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
#  GNU General Public License for more details.                            #
#                                                                          #
############################################################################
import urllib,urllib2,webbrowser,sys,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,subprocess
from libs import addonwindow as pyxbmct
ADDON_ID         = 'script.ftgpair'
HOME             = xbmc.translatePath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PLUGIN           = os.path.join(ADDONS,    ADDON_ID)
FANART           = os.path.join(PLUGIN,    'fanart.jpg')
ICON             = os.path.join(PLUGIN,    'icon.png')
ART              = os.path.join(PLUGIN,    'libs', 'art')
FTG              = pyxbmct.AddonDialogWindow('')
EXIT             = os.path.join(ART , 'redB.png')
FBUTTON          = os.path.join(ART , 'yellowB.png') 
BUTTON           = os.path.join(ART , 'button.png')
LOGO             = os.path.join(ART , 'logo.gif')
TITLE            = os.path.join(ART , 'title.png')
def site(items):
	if items == 'openload':
		site = 'https://olpair.com/'
		opensite(site)
	if items == 'vshareeu':
		site = 'http://vshare.eu/pair'
		opensite(site)
	if items == 'flashx':
		site = 'https://www.flashx.tv/pairing.php'
		opensite(site)
	if items == 'streamc':
		site = 'https://streamcherry.com/pair'
		opensite(site)
	if items == 'streamango':
		site = 'https://streamango.com/pair'
		opensite(site)
	if items == 'RDresolveURL':
		xbmc.executebuiltin("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")
		site = 'https://real-debrid.com/device'
		time.sleep(22)
		opensite(site)
	if items == 'RDURLResolver':
		xbmc.executebuiltin("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")
		site = 'https://real-debrid.com/device'
		time.sleep(22)
		opensite(site)
	if items == 'ADresolveURL':
		xbmc.executebuiltin("RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)")
		site = 'https://alldebrid.com/pin'
		time.sleep(22)
		opensite(site)
	if items == 'ADURLResolver':
		xbmc.executebuiltin("RunPlugin(plugin://script.module.urlresolver/?mode=auth_ad)")
		site = 'https://alldebrid.com/pin'
		time.sleep(22)
		opensite(site)
def opensite(site):
	os = platform()
	if os == 'android':
		xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' % (site) )
	if os == 'osx':
		os.system("open -a /Applications/Safari.app %s") % (site)
		#os.system('open' + site)
	if os == 'linux':
		subprocess.Popen(['xdg-open', site])
	else:
		webbrowser.open(site)
def platform():
	if xbmc.getCondVisibility('system.platform.android'):
		return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):
		return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'ios'
#################################################################
FTG.setGeometry(640, 360, 100, 50)
fan=pyxbmct.Image(FANART)
FTG.placeControl(fan, -10, -6, 125, 62)
logo=pyxbmct.Image(LOGO)
FTG.placeControl(logo, 35, 16, 45, 19)
titletx   = pyxbmct.Image(TITLE)
FTG.placeControl(titletx, -8, 0 , 20, 50)
God_is_Great1= pyxbmct.Button('[B]OpenLoad[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(God_is_Great1,17 , 1 , 13, 15)
FTG.connect(God_is_Great1, lambda: site('openload'))
God_is_Great2= pyxbmct.Button('[B]V Share EU[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(God_is_Great2,30 , 1 , 13, 15)
FTG.connect(God_is_Great2, lambda: site('vshareeu'))
God_is_Great3= pyxbmct.Button('[B]Stream Cherry[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(God_is_Great3,43 , 1 , 13, 15)
FTG.connect(God_is_Great3, lambda: site('streamc'))
God_is_Great4= pyxbmct.Button('[B]Streamango[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(God_is_Great4,56 , 1 , 13, 15)
FTG.connect(God_is_Great4, lambda: site('streamango'))
RDtext   = pyxbmct.Label('[COLOR cyan][B]Real Debrid[/B][/COLOR]')
FTG.placeControl(RDtext, 17, 36, 10, 25)
God_is_Great5= pyxbmct.Button('[B]ResolveURL[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(God_is_Great5,30 , 35 , 13, 15)
FTG.connect(God_is_Great5, lambda: site('RDresolveURL'))
God_is_Great6= pyxbmct.Button('[B]URLResolver[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(God_is_Great6,43 , 35 , 13, 15)
FTG.connect(God_is_Great6, lambda: site('RDURLResolver'))
ADtext   = pyxbmct.Label('[COLOR cyan][B]All Debrid[/B][/COLOR]')
FTG.placeControl(ADtext, 56, 36, 13, 25)
God_is_Great7= pyxbmct.Button('[B]ResolveURL[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(God_is_Great7,69 , 35 , 13, 15)
FTG.connect(God_is_Great7, lambda: site('ADresolveURL'))
God_is_Great8= pyxbmct.Button('[B]URLResolver[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(God_is_Great8,82 , 35 , 13, 15)
FTG.connect(God_is_Great8, lambda: site('ADURLResolver'))
CloseButton = pyxbmct.Button('[B]Close[/B]',focusTexture=EXIT,noFocusTexture=BUTTON)
FTG.placeControl(CloseButton,99 , 18 ,13, 15)
FTG.connect(CloseButton, FTG.close)
God_is_Great1.controlUp(God_is_Great4)
God_is_Great1.controlDown(God_is_Great2)
God_is_Great1.controlRight(God_is_Great5)
God_is_Great2.controlUp(God_is_Great1)
God_is_Great2.controlDown(God_is_Great3)
God_is_Great2.controlRight(God_is_Great6)
God_is_Great3.controlUp(God_is_Great2)
God_is_Great3.controlDown(God_is_Great4)
God_is_Great3.controlRight(God_is_Great7)
God_is_Great4.controlUp(God_is_Great3)
God_is_Great4.controlDown(CloseButton)
God_is_Great4.controlRight(God_is_Great8)
God_is_Great5.controlUp(God_is_Great8)
God_is_Great5.controlLeft(God_is_Great1)
God_is_Great5.controlDown(God_is_Great6)
God_is_Great6.controlUp(God_is_Great5)
God_is_Great6.controlLeft(God_is_Great2)
God_is_Great6.controlDown(God_is_Great7)
God_is_Great7.controlUp(God_is_Great6)
God_is_Great7.controlLeft(God_is_Great3)
God_is_Great7.controlDown(God_is_Great8)
God_is_Great8.controlUp(God_is_Great7)
God_is_Great8.controlLeft(God_is_Great4)
God_is_Great8.controlDown(CloseButton)
CloseButton.controlUp(God_is_Great4)
CloseButton.controlLeft(God_is_Great4)
CloseButton.controlRight(God_is_Great8)
FTG.setFocus(God_is_Great1)
FTG.connect(pyxbmct.ACTION_NAV_BACK, FTG.close)
FTG.doModal()
del FTG 