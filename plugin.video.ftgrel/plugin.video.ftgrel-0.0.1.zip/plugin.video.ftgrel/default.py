

import urlparse,sys,re

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))

action = params.get('action')

content = params.get('content')

name = params.get('name')

url = params.get('url')

image = params.get('image')

fanart = params.get('fanart')


if action == None:
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().root()

elif action == 'message':
    from resources.lib.modules import notify
    notify.message(url)

elif action == 'directory':
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().get(url)

elif action == 'qdirectory':
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().getq(url)

elif action == 'xdirectory':
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().getx(url)

elif action == 'developer':
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().developer()

elif action == 'tvtuner':
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().tvtuner(url)

elif 'youtube' in str(action):
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().youtube(url, action)

elif action == 'play':
    from resources.lib.indexers import ftgrel
    ftgrel.player().play(url, content)

elif action == 'browser':
    from resources.lib.indexers import ftgrel
    ftgrel.resolver().browser(url)

elif action == 'search':
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().search(url=None)

elif action == 'addSearch':
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().addSearch(url)

elif action == 'delSearch':
    from resources.lib.indexers import ftgrel
    ftgrel.indexer().delSearch()

elif action == 'queueItem':
    from resources.lib.modules import control
    control.queueItem()

elif action == 'openSettings':
    from resources.lib.modules import control
    control.openSettings()

elif action == 'urlresolverSettings':
    from resources.lib.modules import control
    control.openSettings(id='script.module.urlresolver')

elif action == 'addView':
    from resources.lib.modules import views
    views.addView(content)

elif action == 'trailer':
    from resources.lib.modules import trailer
    trailer.trailer().play(name)

elif action == 'clearCache':
    from resources.lib.modules import cache
    cache.clear()



else:
    if 'search' in action:
        url = action.split('search=')[1]
        url = url + '|SECTION|'
        from resources.lib.indexers import ftgrel
        ftgrel.indexer().search(url)
    else: quit()
