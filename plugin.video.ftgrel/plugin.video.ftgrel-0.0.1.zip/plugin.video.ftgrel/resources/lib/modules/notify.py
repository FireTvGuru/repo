

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil,requests
import urllib2,urllib
import re
import time
from datetime import date, datetime, timedelta
ADDON_ID            = 'plugin.video.ftgrel'
AddonTitle          = '[COLOR orange]FTG[/COLOR] Religion'
fanart              = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
icon                = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))
HOME                = xbmc.translatePath('special://home/')
ADDON_FOLDER        = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID))
ADDONS         = os.path.join(HOME,     'addons')
ADDON_FOLDER = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID))

def message(url):
	n=requests.get('http://pastebin.com/raw/PyF8xYse')
	TextBox('[COLOR orange]FTG[/COLOR] Religion',n.text)

def TextBox(title, msg):
	class TextBoxes(xbmcgui.WindowXMLDialog):
		def onInit(self):
			self.title      = 100
			self.msg        = 101
			self.okbutton   = 102
			self.scrollbar  = 104

			self.showdialog()

		def showdialog(self):
		
			self.getControl(self.title).setLabel(title)
			self.getControl(self.msg).setText(msg)
			self.setFocusId(self.scrollbar)

			
		def onClick(self, controlId):
			if (controlId == self.okbutton):
				self.close()
			elif (controlId == self.uploadbutton):
				uploadlog.main(argv=None)	

	tb = TextBoxes( "textbox.xml" , ADDON_FOLDER, 'DefaultSkin', title=title, msg=msg)
	tb.doModal()
	del tb
