############################################################################
#                             /T /I                                        #
#                              / |/ | .-~/                                 #
#                          T\ Y  I  |/  /  _                               #
#         /T               | \I  |  I  Y.-~/                               #
#        I l   /I       T\ |  |  l  |  T  /                                #
#     T\ |  \ Y l  /T   | \I  l   \ `  l Y       If your going to copy     #
# __  | \l   \l  \I l __l  l   \   `  _. |       this addon just           #
# \ ~-l  `\   `\  \  \ ~\  \   `. .-~   |        give credit!              #
#  \   ~-. "-.  `  \  ^._ ^. "-.  /  \   |                                 #
#.--~-._  ~-  `  _  ~-_.-"-." ._ /._ ." ./        Stop Deleting the        #
# >--.  ~-.   ._  ~>-"    "\   7   7   ]          credits file!            #
#^.___~"--._    ~-{  .-~ .  `\ Y . /    |                                  #
# <__ ~"-.  ~       /_/   \   \I  Y   : |                                  #
#   ^-.__           ~(_/   \   >._:   | l______                            #
#       ^--.,___.-~"  /_/   !  `-.~"--l_ /     ~"-.                        #
#              (_/ .  ~(   /'     "~"--,Y   -=b-. _)                       #
#               (_/ .  \  :           / l      c"~o \                      #
#                \ /    `.    .     .^   \_.-~"~--.  )                     #
#                 (_/ .   `  /     /       !       )/                      #
#                  / / _.   '.   .':      /        '                       #
#                  ~(_/ .   /    _  `  .-<_                                #
#                    /_/ . ' .-~" `.  / \  \          ,z=.  Surfacingx     #
#                    ~( /   '  :   | K   "-.~-.______//   Original Author  #
#                      "-,.    l   I/ \_    __{--->._(==.                  #
#                       //(     \  <    ~"~"     //                        #
#                      /' /\     \  \     ,v=.  ((     Fire TV Guru        #
#                    .^. / /\     "  }__ //===-  `    PyXBMCt LaYOUt       #
#                   / / ' '  "-.,__ {---(==-                               #
#                 .^ '       :  T  ~"   ll                                 #
#                / .  .  . : | :!        \                                 #
#               (_/  /   | | j-"          ~^                               #
#                 ~-<_(_.^-~"                                              #
#                                                                          #
#                  Copyright (C) One of those Years....                    #
#                                                                          #
#  This program is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by    #
#  the Free Software Foundation, either version 3 of the License, or       #
#  (at your option) any later version.                                     #
#                                                                          #
#  This program is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of          #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
#  GNU General Public License for more details.                            #
#                                                                          #
############################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import urllib2,urllib
import re
import zipfile
import uservar
import fnmatch
import pyxbmct
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
from datetime import date, datetime, timedelta
from urlparse import urljoin
from resources.libs import extract, downloader, notify, skinSwitch, uploadLog, yt, speedtest, wizard as wiz

ADDON_ID         = uservar.ADDON_ID
ADDONTITLE       = uservar.ADDONTITLE
ADDON            = wiz.addonId(ADDON_ID)
VERSION          = wiz.addonInfo(ADDON_ID,'version')
ADDONPATH        = wiz.addonInfo(ADDON_ID, 'path')
DIALOG           = xbmcgui.Dialog()
DP               = xbmcgui.DialogProgress()
HOME             = xbmc.translatePath('special://home/')
LOG              = xbmc.translatePath('special://logpath/')
PROFILE          = xbmc.translatePath('special://profile/')
TEMPDIR          = xbmc.translatePath('special://temp')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PLUGIN           = os.path.join(ADDONS,    ADDON_ID)
PACKAGES         = os.path.join(ADDONS,    'packages')
ADDOND           = os.path.join(USERDATA,  'addon_data')
ADDONDATA        = os.path.join(USERDATA,  'addon_data', ADDON_ID)
ADVANCED         = os.path.join(USERDATA,  'advancedsettings.xml')
SOURCES          = os.path.join(USERDATA,  'sources.xml')
FAVOURITES       = os.path.join(USERDATA,  'favourites.xml')
PROFILES         = os.path.join(USERDATA,  'profiles.xml')
GUISETTINGS      = os.path.join(USERDATA,  'guisettings.xml')
THUMBS           = os.path.join(USERDATA,  'Thumbnails')
DATABASE         = os.path.join(USERDATA,  'Database')
FANART           = os.path.join(PLUGIN,    'fanart.jpg')
ICON             = os.path.join(PLUGIN,    'icon.png')
ART              = os.path.join(PLUGIN,    'resources', 'art')
WIZLOG           = os.path.join(ADDONDATA, 'wizard.log')
SPEEDTESTFOLD    = os.path.join(ADDONDATA, 'SpeedTest')
ARCHIVE_CACHE    = os.path.join(TEMPDIR,   'archive_cache')
SKIN             = xbmc.getSkinDir()
AUTOCLEANUP      = wiz.getS('autoclean')
AUTOCACHE        = wiz.getS('clearcache')
AUTOPACKAGES     = wiz.getS('clearpackages')
AUTOTHUMBS       = wiz.getS('clearthumbs')
AUTOFEQ          = wiz.getS('autocleanfeq')
AUTONEXTRUN      = wiz.getS('nextautocleanup')

SEPERATE         = wiz.getS('seperate')
NOTIFY           = wiz.getS('notify')
NOTEID           = wiz.getS('noteid')
NOTEDISMISS      = wiz.getS('notedismiss')
KEEPFAVS         = wiz.getS('keepfavourites')
FAVSsave         = wiz.getS('favouriteslastsave')
KEEPSOURCES      = wiz.getS('keepsources')
KEEPPROFILES     = wiz.getS('keepprofiles')
KEEPADVANCED     = wiz.getS('keepadvanced')
KEEPREPOS        = wiz.getS('keeprepos')
KEEPSUPER        = wiz.getS('keepsuper')
KEEPWHITELIST    = wiz.getS('keepwhitelist')
KEEPTRAKT        = wiz.getS('keeptrakt')
KEEPREAL         = wiz.getS('keepdebrid')
KEEPALLUC        = wiz.getS('keepalluc')
KEEPLOGIN        = wiz.getS('keeplogin')
DEVELOPER        = wiz.getS('developer')
BACKUPLOCATION   = ADDON.getSetting('path') if not ADDON.getSetting('path') == '' else 'special://home/'
MYBUILDS         = os.path.join(BACKUPLOCATION, 'My_Builds', '')
AUTOFEQ          = int(float(AUTOFEQ)) if AUTOFEQ.isdigit() else 0
TODAY            = date.today()
TOMORROW         = TODAY + timedelta(days=1)
THREEDAYS        = TODAY + timedelta(days=3)
KODIV            = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
MCNAME           = wiz.mediaCenter()
EXCLUDES         = uservar.EXCLUDES
CACHETEXT        = uservar.CACHETEXT
CACHEAGE         = uservar.CACHEAGE if str(uservar.CACHEAGE).isdigit() else 30
UPDATECHECK      = uservar.UPDATECHECK if str(uservar.UPDATECHECK).isdigit() else 1
NEXTCHECK        = TODAY + timedelta(days=UPDATECHECK)
AUTOUPDATE       = uservar.AUTOUPDATE
HIDESPACERS      = uservar.HIDESPACERS
COLOR1           = uservar.COLOR1
COLOR2           = uservar.COLOR2
THEME1           = uservar.THEME1
THEME2           = uservar.THEME2
THEME3           = uservar.THEME3
THEME4           = uservar.THEME4
THEME5           = uservar.THEME5
THEME6           = uservar.THEME6
ICONBUILDS       = uservar.ICONBUILDS if not uservar.ICONBUILDS == 'http://' else ICON
ICONMAINT        = uservar.ICONMAINT if not uservar.ICONMAINT == 'http://' else ICON
ICONAPK          = uservar.ICONAPK if not uservar.ICONAPK == 'http://' else ICON
ICONADDONS       = uservar.ICONADDONS if not uservar.ICONADDONS == 'http://' else ICON
ICONYOUTUBE      = uservar.ICONYOUTUBE if not uservar.ICONYOUTUBE == 'http://' else ICON
ICONSAVE         = uservar.ICONSAVE if not uservar.ICONSAVE == 'http://' else ICON
ICONTRAKT        = uservar.ICONTRAKT if not uservar.ICONTRAKT == 'http://' else ICON
ICONREAL         = uservar.ICONREAL if not uservar.ICONREAL == 'http://' else ICON
ICONLOGIN        = uservar.ICONLOGIN if not uservar.ICONLOGIN == 'http://' else ICON
ICONCONTACT      = uservar.ICONCONTACT if not uservar.ICONCONTACT == 'http://' else ICON
ICONSETTINGS     = uservar.ICONSETTINGS if not uservar.ICONSETTINGS == 'http://' else ICON
Images           = xbmc.translatePath(os.path.join('special://home','addons',ADDON_ID,'resources','images/'));
LOGFILES         = wiz.LOGFILES
ADVANCEDFILE     = uservar.ADVANCEDFILE
DEFAULTPLUGINS   = ['metadata.album.universal', 'metadata.artists.universal', 'metadata.common.fanart.tv', 'metadata.common.imdb.com', 'metadata.common.musicbrainz.org', 'metadata.themoviedb.org', 'metadata.tvdb.com', 'service.xbmc.versioncheck']
#FTG MOD##
speedBG = os.path.join(ART, 'speedtest.jpg')
BG = os.path.join(ART, 'BG.jpg')
sysBG = os.path.join(ART, 'ContentPanel.png')
###########################################

class MaintWindow(pyxbmct.AddonDialogWindow):
	#pyxbmct.skin.estuary = False

	def __init__(self, title=''):
		super(MaintWindow, self).__init__(title)
		self.setGeometry(1280, 720, 18, 8)
		fan=pyxbmct.Image(BG)
		self.placeControl(fan,-2, -1, 21, 11)
		self.add_controls()
		self.set_navigation()
		# Connect a key action (Backspace) to close the window.
		self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

	def add_controls(self):
		self.maint_labels()
		self.misc_buttons()
		self.log_tools()
		self.backup_tools()
		#self.whitelist()
		self.net_tools()
		self.addon_tools()
		self.advanced_setting()
		self.sys_info()

	def maint_labels(self):
		sizepack   = wiz.getSize(PACKAGES)
		sizethumb  = wiz.getSize(THUMBS)
		sizecache  = wiz.getCacheSize()
		totalsize  = sizepack+sizethumb+sizecache
		#label#
		Total = pyxbmct.Label('[COLOR lime]                  Clean up Tools[/COLOR]')
		self.placeControl(Total, 0, 0, 1, 2)
		#buttons#
		self.total_clean_button = pyxbmct.Button('Total Clean Up: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(totalsize))
		self.placeControl(self.total_clean_button, 1, 0, 1, 2)
		self.total_cache_button = pyxbmct.Button('Delete Cache: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizecache))
		self.placeControl(self.total_cache_button, 2, 0, 1, 2)
		self.total_packages_button = pyxbmct.Button('Delete Packages: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizepack))
		self.placeControl(self.total_packages_button, 3, 0, 1, 2)
		self.total_thumbnails_button = pyxbmct.Button('Delete Thumbnails: [COLOR green][B]%s[/B][/COLOR]' % wiz.convertSize(sizethumb))
		self.placeControl(self.total_thumbnails_button, 4, 0, 1, 2)
		#connect#
		self.connect(self.total_clean_button, self.totalClean)
		self.connect(self.total_cache_button, self.clearCache)
		self.connect(self.total_packages_button, self.clearpacks)
		self.connect(self.total_thumbnails_button, self.clearThumb)

	def log_tools(self):
		errors = int(errorChecking(count=True))
		err = str(errors)
		errorsfound = '[COLOR red]%s[/COLOR] Found'  % (err) if errors > 0 else 'None Found'
		on = '[B][COLOR green]ON[/COLOR][/B]'; off = '[B][COLOR red]OFF[/COLOR][/B]'
		if wiz.Grab_Log(True) == False: kodilog = 0
		else: kodilog = errorChecking(wiz.Grab_Log(True), True)
		if wiz.Grab_Log(True, True) == False: kodioldlog = 0
		else: kodioldlog = errorChecking(wiz.Grab_Log(True,True), True)
		errorsinlog = int(kodilog) + int(kodioldlog)
		wizlogsize = ': [COLOR red]Not Found[/COLOR]' if not os.path.exists(WIZLOG) else ": [COLOR green]%s[/COLOR]" % wiz.convertSize(os.path.getsize(WIZLOG))
		#label#
		Log_title = pyxbmct.Label('[B][COLOR lime]               Logging Tools[/COLOR][/B]')
		self.placeControl(Log_title, 6, 0, 1, 2)
		Log_errors = pyxbmct.Label('[B]Errors in Log:[/B] %s' % (errorsfound))
		self.placeControl(Log_errors, 7, 0, 1, 2)
		#Buttons#
		self.view_error_button = pyxbmct.Button('[B]View Errors[/B]')
		self.placeControl(self.view_error_button, 8, 0, 1, 2)
		self.full_log_button = pyxbmct.Button('[B]View Full Log[/B]')
		self.placeControl(self.full_log_button, 9, 0, 1, 2)
		self.upload_log_button = pyxbmct.Button('[B]Upload Full Log[/B]')
		self.placeControl(self.upload_log_button, 10, 0, 1, 2)
		#Connect#
		self.connect(self.view_error_button, self.view_error)
		self.connect(self.full_log_button, self.full_log)
		self.connect(self.upload_log_button, self.uploadLog)

	def backup_tools(self):
		last = str(FAVSsave) if not FAVSsave == '' else 'Favourites hasnt been saved yet.'
		#label#
		Backup = pyxbmct.Label('[B][COLOR lime]       Backup/Restore Tools[/COLOR][/B]')
		self.placeControl(Backup, 0, 6, 1, 2)
		fav = pyxbmct.Label('[B][COLOR lime]            Favourite Tools[/COLOR][/B]')
		self.placeControl(fav, 10, 6, 1, 2)
		self.favs = pyxbmct.FadeLabel()
		self.placeControl(self.favs, 11, 6, 1, 2)
		self.favs.addLabel('[B]Last Save: %s[/B]' % str(last))
		#textbox#
		self.textbox = pyxbmct.TextBox()
		self.placeControl(self.textbox, 1, 6, 1, 2)
		self.textbox.setText('[B]Back-Up Location:[/B] [B][COLOR yellow]%s[/COLOR][/B]' % (MYBUILDS))
		self.textbox.autoScroll(1000, 1000, 1000)
		#buttons#
		self.backup_build_button = pyxbmct.Button('[B]Back-Up: Build[/B]')
		self.placeControl(self.backup_build_button, 2, 6, 1, 2)
		self.backup_gui_button = pyxbmct.Button('[B]Back-Up: GUI[/B]')
		self.placeControl(self.backup_gui_button, 3, 6, 1, 2)
		self.backupaddonpack_button = pyxbmct.Button('[B]Back-Up: Addon Pack[/B]')
		self.placeControl(self.backupaddonpack_button, 4, 6, 1, 2)
		self.backup_addondata_button = pyxbmct.Button('[B]Back-Up: Addon Data[/B]')
		self.placeControl(self.backup_addondata_button, 5, 6, 1, 2)
		self.restore_build_button = pyxbmct.Button('[B]Restore: Build / Pack[/B]')
		self.placeControl(self.restore_build_button, 6, 6, 1, 2)
		self.restore_gui_button = pyxbmct.Button('[B]Restore: GUI[/B]')
		self.placeControl(self.restore_gui_button, 7, 6, 1, 2)
		self.restore_addondata_button = pyxbmct.Button('[B]Restore: Addon Data[/B]')
		self.placeControl(self.restore_addondata_button, 8, 6, 1, 2)
		self.clear_backup_button = pyxbmct.Button('[B]Clear Back-ups[/B]')
		self.placeControl(self.clear_backup_button, 9, 6, 1, 2)
		#favs#
	
	
		self.savefav_button = pyxbmct.Button('[B]Back-Up: Favourites[/B]')
		self.placeControl(self.savefav_button, 12, 6, 1, 2)
		self.restorefav_button = pyxbmct.Button('[B]Restore: Favourites[/B]')
		self.placeControl(self.restorefav_button, 13, 6, 1, 2)
		self.clearfav_button = pyxbmct.Button('[B]Clear Favourite[/B]')
		self.placeControl(self.clearfav_button, 14, 6, 1, 2)
		#Connect#
		self.connect(self.backup_build_button, self.backupbuild)
		self.connect(self.backup_gui_button, self.backupgui)
		self.connect(self.backup_addondata_button, self.backupaddon)
		self.connect(self.restore_build_button, self.restorezip)
		self.connect(self.restore_gui_button, self.restoregui)
		self.connect(self.restore_addondata_button, self.view_error)
		self.connect(self.clear_backup_button, self.restoreaddon)
		self.connect(self.savefav_button, self.savefav)
		self.connect(self.restorefav_button, self.restorefav)
		self.connect(self.clearfav_button, self.clearfav)
		self.connect(self.backupaddonpack_button, self.backupaddonpack)

	def whitelist(self):
		#label#
		WhiteList = pyxbmct.Label('[B][COLOR lime]              White List Tools[/COLOR][/B]')
		self.placeControl(WhiteList, 1, 4, 1, 2)
		#buttons#
		self.whitelist_edit_button = pyxbmct.Button('[B]WhiteList: Edit[/B]')
		self.placeControl(self.whitelist_edit_button, 2, 4, 1, 2)
		self.whitelist_view_button = pyxbmct.Button('[B]WhiteList: View[/B]')
		self.placeControl(self.whitelist_view_button, 3, 4, 1, 2)
		self.whitelist_clear_button = pyxbmct.Button('[B]WhiteList: Clear[/B]')
		self.placeControl(self.whitelist_clear_button, 4, 4, 1, 2)
		self.whitelist_import_button = pyxbmct.Button('[B]WhiteList: Import[/B]')
		self.placeControl(self.whitelist_import_button, 5, 4, 1, 2)
		self.whitelist_export_button = pyxbmct.Button('[B]WhiteList: Export[/B]')
		self.placeControl(self.whitelist_export_button, 6, 4, 1, 2)
		#Connect#
		self.connect(self.whitelist_edit_button, self.whiteliste)
		self.connect(self.whitelist_view_button, self.whitelistv)
		self.connect(self.whitelist_clear_button, self.whitelistc)
		self.connect(self.whitelist_import_button, self.whitelisti)
		self.connect(self.whitelist_export_button, self.whitelistex)

	def misc_buttons(self):
		##Close Button Always Needed!##
		self.close_button = pyxbmct.Button('[B]Close[/B]', font='font18')
		self.placeControl(self.close_button, 16, 7, 2, 1)
		# Connect control to close the window.#
		self.connect(self.close_button, self.close)
		#buttons#
		self.settings_button = pyxbmct.Button('[B]Settings[/B]', font='font18')
		self.placeControl(self.settings_button, 16, 6, 2, 1)
		#connect#
		self.connect(self.settings_button, self.settings)

	def net_tools(self):
		#button#
		self.speed_test_button = pyxbmct.Button('[B][COLOR yellow]Test Your Internet Speed[/COLOR][/B]')
		self.placeControl(self.speed_test_button, 12, 0, 1, 2)
		self.view_ip_button = pyxbmct.Button('[B][COLOR yellow]Whats my IP[/COLOR][/B]')
		self.placeControl(self.view_ip_button, 12, 2)
		#image#
		self.speedthumb=pyxbmct.Image(speedBG)
		self.placeControl(self.speedthumb, 13, 0, 5, 3)
		#connect#
		self.connect(self.speed_test_button, self.speedtest)
		self.connect(self.view_ip_button, self.viewIP)

	def advanced_setting(self):
		#label#
		Addon = pyxbmct.Label('[B][COLOR lime]     Advanced Settings Tools[/COLOR][/B]')
		self.placeControl(Addon, 1, 4, 1, 2)
		#buttons#
		self.autoadvanced_button = pyxbmct.Button('[B]Quick AdvancedSettings.xml[/B]')
		self.placeControl(self.autoadvanced_button, 2, 4, 1, 2)
		self.autoadvanced1_button = pyxbmct.Button('[B]Full AdvancedSettings.xml[/B]')
		self.placeControl(self.autoadvanced1_button, 3, 4, 1, 2)
		self.currentsettings_button = pyxbmct.Button('[B]Current AdvancedSettings[/B]')
		self.placeControl(self.currentsettings_button, 4, 4, 1, 2)
		self.removeadvanced_button = pyxbmct.Button('[B]Delete AdvancedSettings[/B]')
		self.placeControl(self.removeadvanced_button, 5, 4, 1, 2)
		#connect#
		self.connect(self.currentsettings_button, self.currentsettings)
		self.connect(self.removeadvanced_button, self.removeadvanced)
		self.connect(self.autoadvanced_button, self.autoadvanced)
		self.connect(self.autoadvanced1_button, self.autoadvanced1)

	def addon_tools(self):
		#label#
		Addon = pyxbmct.Label('[B][COLOR lime]                 Addon Tools[/COLOR][/B]')
		self.placeControl(Addon, 1, 2, 1, 2)
		#buttons#
		self.checksources_button = pyxbmct.Button('[B]Scan For Broken Sources[/B]')
		self.placeControl(self.checksources_button, 2, 2, 1, 2)
		self.checkrepos_button = pyxbmct.Button('[B]Scan For Broken Repositories[/B]')
		self.placeControl(self.checkrepos_button, 3, 2, 1, 2)
		self.forceupdate_button = pyxbmct.Button('[B]Force Update Addons[/B]')
		self.placeControl(self.forceupdate_button, 4, 2, 1, 2)
		self.fixaddonupdate_button = pyxbmct.Button('[B]Fix Addons Not Updating[/B]')
		self.placeControl(self.fixaddonupdate_button, 5, 2, 1, 2)
		self.removeaddons_button = pyxbmct.Button('[B]Delete Selected Addons[/B]')
		self.placeControl(self.removeaddons_button, 6, 2, 1, 2)
		self.removeaddondata_u_button = pyxbmct.Button('[B]Delete Uninstalled Addon Folders[/B]')
		self.placeControl(self.removeaddondata_u_button, 7, 2, 1, 2)
		self.removeaddondata_e_button = pyxbmct.Button('[B]Delete Empty Addon Folders[/B]')
		self.placeControl(self.removeaddondata_e_button, 8, 2, 1, 2)
		#connect#
		self.connect(self.removeaddons_button, self.removeaddons)
		self.connect(self.removeaddondata_u_button, self.removeaddondata_u)
		self.connect(self.removeaddondata_e_button, self.removeaddondata_e)
		self.connect(self.checksources_button, self.checksources)
		self.connect(self.checkrepos_button, self.checkrepos)
		self.connect(self.forceupdate_button, self.forceupdate)
		self.connect(self.fixaddonupdate_button, self.fixaddonupdate)

	def sys_info(self):
		infoLabel = ['System.FriendlyName', 
					'System.BuildVersion', 
					'System.CpuUsage',
					'System.ScreenMode',
					'Network.IPAddress',
					'Network.MacAddress',
					'System.Uptime',
					'System.TotalUptime',
					'System.FreeSpace',
					'System.UsedSpace',
					'System.TotalSpace',
					'System.Memory(free)',
					'System.Memory(used)',
					'System.Memory(total)']
		data      = []; x = 0
		for info in infoLabel:
			temp = wiz.getInfo(info)
			y = 0
			while temp == "Busy" and y < 10:
				temp = wiz.getInfo(info); y += 1; wiz.log("%s sleep %s" % (info, str(y))); xbmc.sleep(200)
			data.append(temp)
			x += 1
		storage_free  = data[8] if 'Una' in data[8] else wiz.convertSize(int(float(data[8][:-8]))*1024*1024)
		storage_used  = data[9] if 'Una' in data[9] else wiz.convertSize(int(float(data[9][:-8]))*1024*1024)
		storage_total = data[10] if 'Una' in data[10] else wiz.convertSize(int(float(data[10][:-8]))*1024*1024)
		ram_free      = wiz.convertSize(int(float(data[11][:-2]))*1024*1024)
		ram_used      = wiz.convertSize(int(float(data[12][:-2]))*1024*1024)
		ram_total     = wiz.convertSize(int(float(data[13][:-2]))*1024*1024)
		
		xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
		version=float(xbmc_version[:4])
		if version >= 11.0 and version <= 11.9:
			codename = 'Eden'
		elif version >= 12.0 and version <= 12.9:
			codename = 'Frodo'
		elif version >= 13.0 and version <= 13.9:
			codename = 'Gotham'
		elif version >= 14.0 and version <= 14.9:
			codename = 'Helix'
		elif version >= 15.0 and version <= 15.9:
			codename = 'Isengard'
		elif version >= 16.0 and version <= 16.9:
			codename = 'Jarvis'
		elif version >= 17.0 and version <= 17.9:
			codename = 'Krypton'
		elif version >= 18.0 and version <= 18.9:
			codename = 'Leia'
		else: codename = "Decline"
		picture = []; music = []; video = []; programs = []; repos = []; scripts = []; skins = []
		
		fold = glob.glob(os.path.join(ADDONS, '*/'))
		for folder in sorted(fold, key = lambda x: x):
			foldername = os.path.split(folder[:-1])[1]
			if foldername == 'packages': continue
			xml = os.path.join(folder, 'addon.xml')
			if os.path.exists(xml):
				f      = open(xml)
				a      = f.read()
				prov   = re.compile("<provides>(.+?)</provides>").findall(a)
				if len(prov) == 0:
					if foldername.startswith('skin'): skins.append(foldername)
					elif foldername.startswith('repo'): repos.append(foldername)
					else: scripts.append(foldername)
				elif not (prov[0]).find('executable') == -1: programs.append(foldername)
				elif not (prov[0]).find('video') == -1: video.append(foldername)
				elif not (prov[0]).find('audio') == -1: music.append(foldername)
				elif not (prov[0]).find('image') == -1: picture.append(foldername)
	

		kodi = pyxbmct.Label('   [COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[0]))
		self.placeControl(kodi, 9, 3, 1, 1)
		version1 =  pyxbmct.Label('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR] - [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, codename, COLOR2, version))
		self.placeControl(version1, 9, 4, 1, 2)
		store = pyxbmct.Label('[B][COLOR lime]Storage[/COLOR][/B]')
		self.placeControl(store, 10, 5, 1, 2)
		rom_used=pyxbmct.Label('[COLOR %s]Used:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, storage_free))
		self.placeControl(rom_used, 11, 5, 1, 2)
		rom_free=pyxbmct.Label('[COLOR %s]Free:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, storage_used))
		self.placeControl(rom_free, 12, 5, 1, 2)
		rom_total=pyxbmct.Label('[COLOR %s]Total:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, storage_total))
		self.placeControl(rom_total, 13, 5, 1, 2)
		mem = pyxbmct.Label('[B][COLOR lime]Memory[/COLOR][/B]')
		self.placeControl(mem, 14, 5, 1, 2)
		ram_used=pyxbmct.Label('[COLOR %s]Used:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, ram_used))
		self.placeControl(ram_used, 15, 5, 1, 2)
		ram_free=pyxbmct.Label('[COLOR %s]Free:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, ram_free))
		self.placeControl(ram_free, 16, 5, 1, 2)
		ram_total=pyxbmct.Label('[COLOR %s]Total:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, ram_total))
		self.placeControl(ram_total, 17, 5, 1, 2)
		
		totalcount = len(picture) + len(music) + len(video) + len(programs) + len(scripts) + len(skins) + len(repos) 
		total = pyxbmct.Label('   [COLOR %s]Addons Total:[COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, totalcount))
		self.placeControl(total, 10, 3, 1, 2)
		video=pyxbmct.Label('   [COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(video))))
		self.placeControl(video, 11, 3, 1, 2)
		program=pyxbmct.Label('   [COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(programs))))
		self.placeControl(program, 12, 3, 1, 2)
		music=pyxbmct.Label('   [COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(music))))
		self.placeControl(music, 13, 3, 1, 2)
		picture=pyxbmct.Label('   [COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(picture))))
		self.placeControl(picture, 14, 3, 1, 2)
		repos=pyxbmct.Label('   [COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(repos))))
		self.placeControl(repos, 15, 3, 1, 2)
		skins=pyxbmct.Label('   [COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(skins))))
		self.placeControl(skins, 16, 3, 1, 2)
		scripts=pyxbmct.Label('   [COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, str(len(scripts))))
		self.placeControl(scripts, 17, 3, 1, 2)

	def set_navigation(self):
		# Set navigation between controls
		#Total Clean#
		self.total_clean_button.controlRight(self.checksources_button)
		self.total_clean_button.controlDown(self.total_cache_button)
		#clear cache#
		self.total_cache_button.controlUp(self.total_clean_button)
		self.total_cache_button.controlRight(self.checksources_button)
		self.total_cache_button.controlDown(self.total_packages_button)
		#clear packages#
		self.total_packages_button.controlUp(self.total_cache_button)
		self.total_packages_button.controlRight(self.checkrepos_button)
		self.total_packages_button.controlDown(self.total_thumbnails_button)
		#thumbnails#
		self.total_thumbnails_button.controlUp(self.total_packages_button)
		self.total_thumbnails_button.controlRight(self.forceupdate_button)
		self.total_thumbnails_button.controlDown(self.view_error_button)
		#view error#
		self.view_error_button.controlUp(self.total_thumbnails_button)
		self.view_error_button.controlRight(self.removeaddondata_e_button)
		self.view_error_button.controlDown(self.full_log_button)
		#full error#
		self.full_log_button.controlUp(self.view_error_button)
		self.full_log_button.controlRight(self.removeaddondata_e_button)
		self.full_log_button.controlDown(self.upload_log_button)
		#upload error#
		self.upload_log_button.controlUp(self.full_log_button)
		self.upload_log_button.controlRight(self.removeaddondata_e_button)
		self.upload_log_button.controlDown(self.speed_test_button)
		#speed test#
		self.speed_test_button.controlUp(self.upload_log_button)
		self.speed_test_button.controlRight(self.view_ip_button)
		self.speed_test_button.controlDown(self.speed_test_button)
		#scan sources#
		self.checksources_button.controlLeft(self.total_clean_button)
		self.checksources_button.controlRight(self.autoadvanced_button)
		self.checksources_button.controlDown(self.checkrepos_button)
		#scan repo#
		self.checkrepos_button.controlUp(self.checksources_button)
		self.checkrepos_button.controlLeft(self.total_packages_button)
		self.checkrepos_button.controlRight(self.autoadvanced1_button)
		self.checkrepos_button.controlDown(self.forceupdate_button)
		#force update#
		self.forceupdate_button.controlUp(self.checkrepos_button)
		self.forceupdate_button.controlLeft(self.total_thumbnails_button)
		self.forceupdate_button.controlRight(self.currentsettings_button)
		self.forceupdate_button.controlDown(self.fixaddonupdate_button)
		#fix addon update#
		self.fixaddonupdate_button.controlUp(self.forceupdate_button)
		self.fixaddonupdate_button.controlLeft(self.total_thumbnails_button)
		self.fixaddonupdate_button.controlRight(self.removeadvanced_button)
		self.fixaddonupdate_button.controlDown(self.removeaddons_button)
		#del addons#
		self.removeaddons_button.controlUp(self.fixaddonupdate_button)
		#self.removeaddons_button.controlLeft(self.total_thumbnails_button)
		self.removeaddons_button.controlRight(self.removeadvanced_button)
		self.removeaddons_button.controlDown(self.removeaddondata_u_button)
		#del addon data#
		self.removeaddondata_u_button.controlUp(self.removeaddons_button)
		self.removeaddondata_u_button.controlLeft(self.view_error_button)
		self.removeaddondata_u_button.controlRight(self.removeadvanced_button)
		self.removeaddondata_u_button.controlDown(self.removeaddondata_e_button)
		#del empty folders#
		self.removeaddondata_e_button.controlUp(self.removeaddondata_u_button)
		self.removeaddondata_e_button.controlLeft(self.view_error_button)
		self.removeaddondata_e_button.controlRight(self.removeadvanced_button)
		self.removeaddondata_e_button.controlDown(self.view_ip_button)
		#view ip#
		self.view_ip_button.controlUp(self.removeaddondata_e_button)
		self.view_ip_button.controlLeft(self.speed_test_button)
		self.view_ip_button.controlRight(self.removeadvanced_button)
		#self.view_ip_button.controlDown(self.view_ip_button)
		#q adv set#
		#self.view_ip_button.controlUp(self.Oebhtug Gb Lbh Ol SGT!!)
		self.autoadvanced_button.controlLeft(self.checksources_button)
		self.autoadvanced_button.controlRight(self.backup_build_button)
		self.autoadvanced_button.controlDown(self.autoadvanced1_button)
		#f adv set#
		self.autoadvanced1_button.controlUp(self.autoadvanced_button)
		self.autoadvanced1_button.controlLeft(self.checkrepos_button)
		self.autoadvanced1_button.controlRight(self.backup_gui_button)
		self.autoadvanced1_button.controlDown(self.currentsettings_button)
		#v adv set#
		self.currentsettings_button.controlUp(self.autoadvanced1_button)
		self.currentsettings_button.controlLeft(self.forceupdate_button)
		self.currentsettings_button.controlRight(self.backupaddonpack_button)
		self.currentsettings_button.controlDown(self.removeadvanced_button)
		#d adv set#
		self.removeadvanced_button.controlUp(self.currentsettings_button)
		self.removeadvanced_button.controlLeft(self.fixaddonupdate_button)
		self.removeadvanced_button.controlRight(self.backup_addondata_button)
		self.removeadvanced_button.controlDown(self.removeadvanced_button)
		#b u b#
		#self.backup_build_button.controlUp(self.currentsettings_button)
		self.backup_build_button.controlLeft(self.autoadvanced_button)
		#self.backup_build_button.controlRight(self.backup_addondata_button)
		self.backup_build_button.controlDown(self.backup_gui_button)
		#b u gui#
		self.backup_gui_button.controlUp(self.backup_build_button)
		self.backup_gui_button.controlLeft(self.autoadvanced1_button)
		#self.backup_gui_button.controlRight(self.backup_addondata_#F+T+G#)
		self.backup_gui_button.controlDown(self.backupaddonpack_button)
		#b u a p#
		self.backupaddonpack_button.controlUp(self.backup_gui_button)
		self.backupaddonpack_button.controlLeft(self.currentsettings_button)
		#self.backupaddonpack_button.controlRight(self.backup_addondata_button)
		self.backupaddonpack_button.controlDown(self.backup_addondata_button)
		#b u a d#
		self.backup_addondata_button.controlUp(self.backupaddonpack_button)
		self.backup_addondata_button.controlLeft(self.removeadvanced_button)
		#self.backup_addondata_button.controlRight(Oebhtug Gb Lbh Ol SGT!!)
		self.backup_addondata_button.controlDown(self.restore_build_button)
		#r b p#
		self.restore_build_button.controlUp(self.backup_addondata_button)
		self.restore_build_button.controlLeft(self.removeadvanced_button)
		#self.restore_build_button.controlRight(self.backup_addondata_button)
		self.restore_build_button.controlDown(self.restore_gui_button)
		#r gui#
		self.restore_gui_button.controlUp(self.restore_build_button)
		self.restore_gui_button.controlLeft(self.removeadvanced_button)
		#self.restore_gui_button.controlRight(self.backup_addondata_button)
		self.restore_gui_button.controlDown(self.restore_addondata_button)
		#r a d#
		self.restore_addondata_button.controlUp(self.restore_gui_button)
		self.restore_addondata_button.controlLeft(self.removeadvanced_button)
		#self.restore_addondata_button.controlRight(self.backup_addondata_button)
		self.restore_addondata_button.controlDown(self.clear_backup_button)
		#c b u#
		self.clear_backup_button.controlUp(self.restore_addondata_button)
		self.clear_backup_button.controlLeft(self.removeadvanced_button)
		#self.clear_backup_button.controlRight(self.backup_addondata_button)
		self.clear_backup_button.controlDown(self.savefav_button)
		#s favs#
		self.savefav_button.controlUp(self.clear_backup_button)
		self.savefav_button.controlLeft(self.removeadvanced_button)
		#self.savefav_button.controlRight(self.backup_addondata_button)
		self.savefav_button.controlDown(self.restorefav_button)
		#r favs#
		self.restorefav_button.controlUp(self.savefav_button)
		self.restorefav_button.controlLeft(self.removeadvanced_button)
		#self.restorefav_button.controlRight(self.backup_addondata_button)
		self.restorefav_button.controlDown(self.clearfav_button)
		#c favs#
		self.clearfav_button.controlUp(self.restorefav_button)
		self.clearfav_button.controlLeft(self.removeadvanced_button)
		#self.clearfav_button.controlRight(self.backup_addondata_button)
		self.clearfav_button.controlDown(self.close_button)
		#close#
		self.close_button.controlUp(self.clearfav_button)
		self.close_button.controlLeft(self.settings_button)
		#self.close_button.controlRight(self.backup_addondata_button)
		#self.close_button.controlDown(self.close_button)
		#close#
		self.settings_button.controlUp(self.clearfav_button)
		#self.settings_button.controlLeft(self.settings_button)
		self.settings_button.controlRight(self.close_button)
		#self.settings_button.controlDown(self.settings_button)
		
		#Button to foucus when opened#
		self.setFocus(self.total_clean_button)

	def setAnimation(self, control):
		# Set fade animation for all add-on window controls
		control.setAnimations([('WindowOpen', 'effect=fade delay=0 time=2000 start=0 end=100',),('WindowClose', 'effect=fade delay=0 time=1000 start=100 end=0',)])
#######Ref point##########

	def speedtest(self):
		speed = speedtest.speedtest()
		self.speedthumb.setImage(speed[0])
	def clearCache(self):clearCache(); wiz.refresh()
	def clearpacks(self):wiz.clearPackages('total')
	def totalClean(self):totalClean()
	def clearThumb(self):clearThumb(type=None)
	def view_error(self):errorChecking(log=None, count=None, last=None)
	def full_log(self):LogViewer()
	def uploadLog(self):uploadLog.Main()
	def backupbuild(self):wiz.backUpOptions('build')
	def backupgui(self):wiz.backUpOptions('guifix')
	def backupaddon(self):wiz.backUpOptions('addondata')
	def backupaddonpack(self): wiz.backUpOptions('addon pack')
	def restorezip(self):restoreit('build')
	def restoregui(self):restoreit('gui')
	def restoreaddon(self):restoreit('addondata')
	def clearbackup(self):wiz.cleanupBackup()
	def savefav(self): wiz.BACKUPFAV(); wiz.refresh()
	def restorefav(self):wiz.RESTOREFAV()
	def clearfav(self): wiz.DELFAV()
	def whiteliste(self):wiz.whiteList(edit)
	def whitelistv(self):wiz.whiteList(view)
	def whitelistc(self):wiz.whiteList(clear)
	def whitelisti(self):wiz.whiteList(Import)
	def whitelistex(self):wiz.whiteList(export)
	def viewIP(self):viewIP()
	def removeaddons(self): removeAddonMenu()
	def removeaddondata_u(self): removeAddonDataMenu(uninstalled)
	def removeaddondata_e(self): removeAddonDataMenu(empty)
	def forceupdate(self): wiz.forceUpdate()
	def checksources(self): wiz.checkSources(); wiz.refresh()
	def checkrepos(self): wiz.checkRepos(); wiz.refresh()
	def fixaddonupdate(self): fixUpdate_prompt()
	def currentsettings(self): viewAdvanced()
	def removeadvanced(self): removeAdvanced(); wiz.refresh()
	def autoadvanced(self): notify.autoConfig2(); wiz.refresh()
	def autoadvanced1(self): showAutoAdvanced1(); wiz.refresh()
	def settings(self): wiz.openS(name); wiz.refresh()

def viewIP():
	infoLabel = ['Network.IPAddress',
				 'Network.MacAddress',]
	data      = []; x = 0
	for info in infoLabel:
		temp = wiz.getInfo(info)
		y = 0
		while temp == "Busy" and y < 10:
			temp = wiz.getInfo(info); y += 1; wiz.log("%s sleep %s" % (info, str(y))); xbmc.sleep(200)
		data.append(temp)
		x += 1
	f = urllib.urlopen("http://www.canyouseeme.org/")
	html_doc = f.read()
	f.close()
	m = re.search('IP"\svalue="([^"]*)', html_doc)
	DIALOG.ok("Whats my IP" ,'[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[0]),'[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, m.group(1)),'[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, data[1]))
	

######################################################################################################################################
def installed(addon):
	url = os.path.join(ADDONS,addon,'addon.xml')
	if os.path.exists(url):
		try:
			list  = open(url,mode='r'); g = list.read(); list.close()
			name = wiz.parseDOM(g, 'addon', ret='name', attrs = {'id': addon})
			icon  = os.path.join(ADDONS,addon,'icon.png')
			wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, name[0]), '[COLOR %s]Addon Enabled[/COLOR]' % COLOR2, '2000', icon)
		except: pass
	
def speedTest():
	addFile('Run Speed Test',             'speed',      icon=ICONMAINT, themeit=THEME3)
	if os.path.exists(SPEEDTESTFOLD):
		speedimg = glob.glob(os.path.join(SPEEDTESTFOLD, '*.png'))
		speedimg.sort(key=lambda f: os.path.getmtime(f), reverse=True)
		if len(speedimg) > 0:
			addFile('Clear Results',          'clearspeedtest',    icon=ICONMAINT, themeit=THEME3)
			addFile(wiz.sep('Previous Runs'), '', icon=ICONMAINT, themeit=THEME3)
			for item in speedimg:
				created = datetime.fromtimestamp(os.path.getmtime(item)).strftime('%m/%d/%Y %H:%M:%S')
				img = item.replace(os.path.join(SPEEDTESTFOLD, ''), '')
				addFile('[B]%s[/B]: [I]Ran %s[/I]' % (img, created), 'viewspeedtest', img, icon=ICONMAINT, themeit=THEME3)

def clearSpeedTest():
	speedimg = glob.glob(os.path.join(SPEEDTESTFOLD, '*.png'))
	for file in speedimg:
		wiz.removeFile(file)

def viewSpeedTest(img=None):
	img = os.path.join(SPEEDTESTFOLD, img)
	notify.speedTest(img)

def speed():
	try:
		found = speedtest.speedtest()
		if not os.path.exists(SPEEDTESTFOLD): os.makedirs(SPEEDTESTFOLD)
		urlsplits = found[0].split('/')
		dest = os.path.join(SPEEDTESTFOLD, urlsplits[-1])
		urllib.urlretrieve(found[0], dest)
		viewSpeedTest(urlsplits[-1])
	except:
		wiz.log("[Speed Test] Error Running Speed Test")
		pass

def advancedWindow(url=None):
	if not ADVANCEDFILE == 'http://':
		if url == None:
			TEMPADVANCEDFILE = wiz.textCache(uservar.ADVANCEDFILE)
			if TEMPADVANCEDFILE == False: ADVANCEDWORKING  = wiz.workingURL(uservar.ADVANCEDFILE)
		else:
			TEMPADVANCEDFILE = wiz.textCache(url)
			if TEMPADVANCEDFILE == False: ADVANCEDWORKING  = wiz.workingURL(url)
		addFile('Configure AdvancedSettings.xml', 'autoadvanced1', icon=ICONMAINT, themeit=THEME3)
		addFile('Quick Configure AdvancedSettings.xml', 'autoadvanced', icon=ICONMAINT, themeit=THEME3)
		if os.path.exists(ADVANCED): 
			addFile('View Current AdvancedSettings.xml', 'currentsettings', icon=ICONMAINT, themeit=THEME3)
			addFile('Remove Current AdvancedSettings.xml', 'removeadvanced',  icon=ICONMAINT, themeit=THEME3)
		if not TEMPADVANCEDFILE == False:
			if HIDESPACERS == 'No': addFile(wiz.sep(), '', icon=ICONMAINT, themeit=THEME3)
			link = TEMPADVANCEDFILE.replace('\n','').replace('\r','').replace('\t','')
			match = re.compile('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
			if len(match) > 0:
				for name, section, url, icon, fanart, description in match:
					if section.lower() == "yes":
						addDir ("[B]%s[/B]" % name, 'advancedsetting', url, description=description, icon=icon, fanart=fanart, themeit=THEME3)
					else:
						addFile(name, 'writeadvanced', name, url, description=description, icon=icon, fanart=fanart, themeit=THEME2)
			else: wiz.log("[Advanced Settings] ERROR: Invalid Format.")
		else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING)
	else: wiz.log("[Advanced Settings] not Enabled")

def writeAdvanced(name, url):
	ADVANCEDWORKING = wiz.workingURL(url)
	if ADVANCEDWORKING == True:
		if os.path.exists(ADVANCED): choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, name), yeslabel="[B][COLOR green]Overwrite[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")
		else: choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to download and install [COLOR %s]%s[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, name), yeslabel="[B][COLOR green]Install[/COLOR][/B]", nolabel="[B][COLOR red]Cancel[/COLOR][/B]")

		if choice == 1:
			file = wiz.openURL(url)
			f = open(ADVANCED, 'w'); 
			f.write(file)
			f.close()
			DIALOG.ok(ADDONTITLE, '[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]' % COLOR2)
			wiz.killxbmc(True)
		else: wiz.log("[Advanced Settings] install canceled"); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, ADDONTITLE), "[COLOR %s]Write Cancelled![/COLOR]" % COLOR2); return
	else: wiz.log("[Advanced Settings] URL not working: %s" % ADVANCEDWORKING); wiz.LogNotify('[COLOR %s]%s[/COLOR]' % (COLOR1, ADDONTITLE), "[COLOR %s]URL Not Working[/COLOR]" % COLOR2)

def viewAdvanced():
	if os.path.exists(ADVANCED):
		f = open(ADVANCED)
		a = f.read().replace('\t', '    ')
		wiz.TextBox(ADDONTITLE, a)
		f.close()
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]AdvancedSettings.xml not found[/COLOR]")

def removeAdvanced():
	if os.path.exists(ADVANCED):
		wiz.removeFile(ADVANCED)#Oebhtug Gb Lbh Ol SGT!!
		wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]AdvancedSettings.xml Deleted[/COLOR]")
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]AdvancedSettings.xml not found[/COLOR]")

def showAutoAdvanced():
	notify.autoConfig2()
	
def showAutoAdvanced1():
	notify.autoConfig()

def getIP():
	site  = 'http://whatismyip.network/'
	if not wiz.workingURL(site): return 'Unknown', 'Unknown', 'Unknown'
	page  = wiz.openURL(site).replace('\n','').replace('\r','')
	if not 'Access Denied' in page:
		ipmatch   = re.compile('font size="6">(.+?)</font>').findall(page)
		ipfinal   = ipmatch[0] if (len(ipmatch) > 0) else 'Unknown'
		details   = re.compile('"class="col-sm-6">(.+?)</div>').findall(page)
		provider  = details[0] if (len(details) > 0) else 'Unknown'
		location  = details[1]+', '+details[2]+', '+details[3] if (len(details) > 2) else 'Unknown'
		return ipfinal, provider, location
	else: return 'Unknown', 'Unknown', 'Unknown'

def fixUpdate_prompt():
	if DIALOG.yesno('Fix Addons not Updating', '[COLOR %s]Do you want to Rebuild the addons27.db and Force Cloce Kodi[/COLOR]' % COLOR2, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Rebuild[/COLOR][/B]'):
		fixUpdate()
	else:
		return

def fixUpdate():
	if KODIV < 17: 
		dbfile = os.path.join(DATABASE, wiz.latestDB('Addons'))
		try:
			os.remove(dbfile)
		except Exception, e:
			wiz.log("Unable to remove %s, Purging DB" % dbfile)
			wiz.purgeDb(dbfile)
	else:
		if os.path.exists(os.path.join(USERDATA, 'autoexec.py')):
			temp = os.path.join(USERDATA, 'autoexec_temp.py')
			if os.path.exists(temp): xbmcvfs.delete(temp)
			xbmcvfs.rename(os.path.join(USERDATA, 'autoexec.py'), temp)
		xbmcvfs.copy(os.path.join(PLUGIN, 'resources', 'libs', 'autoexec.py'), os.path.join(USERDATA, 'autoexec.py'))
		dbfile = os.path.join(DATABASE, wiz.latestDB('Addons'))
		try:
			os.remove(dbfile)
		except Exception, e:
			wiz.log("Unable to remove %s, Purging DB" % dbfile)
			wiz.purgeDb(dbfile)
		wiz.killxbmc(True)

def removeAddonMenu():
	fold = glob.glob(os.path.join(ADDONS, '*/'))
	addonnames = []; addonids = []
	for folder in sorted(fold, key = lambda x: x):
		foldername = os.path.split(folder[:-1])[1]
		if foldername in EXCLUDES: continue
		elif foldername in DEFAULTPLUGINS: continue
		elif foldername == 'packages': continue
		xml = os.path.join(folder, 'addon.xml')
		if os.path.exists(xml):
			f      = open(xml)
			a      = f.read()
			match  = wiz.parseDOM(a, 'addon', ret='id')

			addid  = foldername if len(match) == 0 else match[0]
			try: 
				add = xbmcaddon.Addon(id=addid)
				addonnames.append(add.getAddonInfo('name'))
				addonids.append(addid)
			except:
				pass
	if len(addonnames) == 0:
		wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]No Addons To Remove[/COLOR]" % COLOR2)
		return
	if KODIV > 16:
		selected = DIALOG.multiselect("%s: Select the addons you wish to remove." % ADDONTITLE, addonnames)
	else:
		selected = []; choice = 0
		tempaddonnames = ["-- Click here to Continue --"] + addonnames
		while not choice == -1:
			choice = DIALOG.select("%s: Select the addons you wish to remove." % ADDONTITLE, tempaddonnames)
			if choice == -1: break
			elif choice == 0: break
			else: 
				choice2 = (choice-1)
				if choice2 in selected:
					selected.remove(choice2)
					tempaddonnames[choice] = addonnames[choice2]
				else:
					selected.append(choice2)
					tempaddonnames[choice] = "[B][COLOR %s]%s[/COLOR][/B]" % (COLOR1, addonnames[choice2])
	if selected == None: return
	if len(selected) > 0:
		wiz.addonUpdates('set')
		for addon in selected:
			removeAddon(addonids[addon], addonnames[addon], True)

		xbmc.sleep(500)

		yes = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR green]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR red]Force Close[/COLOR][/B]")
		if yes ==1:
			wiz.reloadFix('remove addon')
		else: wiz.addonUpdates('reset'); wiz.killxbmc(True)

def removeAddonDataMenu():
	if os.path.exists(ADDOND):
		addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data', 'removedata', 'all', themeit=THEME2)
		addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons', 'removedata', 'uninstalled', themeit=THEME2)
		addFile('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data', 'removedata', 'empty', themeit=THEME2)
		addFile('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data' % ADDONTITLE, 'resetaddon', themeit=THEME2)
		if HIDESPACERS == 'No': addFile(wiz.sep(), '', themeit=THEME3)
		fold = glob.glob(os.path.join(ADDOND, '*/'))
		for folder in sorted(fold, key = lambda x: x):
			foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
			icon = os.path.join(folder.replace(ADDOND, ADDONS), 'icon.png')
			fanart = os.path.join(folder.replace(ADDOND, ADDONS), 'fanart.png')
			folderdisplay = foldername
			replace = {'audio.':'[COLOR orange][AUDIO] [/COLOR]', 'metadata.':'[COLOR cyan][METADATA] [/COLOR]', 'module.':'[COLOR orange][MODULE] [/COLOR]', 'plugin.':'[COLOR blue][PLUGIN] [/COLOR]', 'program.':'[COLOR orange][PROGRAM] [/COLOR]', 'repository.':'[COLOR gold][REPO] [/COLOR]', 'script.':'[COLOR green][SCRIPT] [/COLOR]', 'service.':'[COLOR green][SERVICE] [/COLOR]', 'skin.':'[COLOR dodgerblue][SKIN] [/COLOR]', 'video.':'[COLOR orange][VIDEO] [/COLOR]', 'weather.':'[COLOR yellow][WEATHER] [/COLOR]'}
			for rep in replace:
				folderdisplay = folderdisplay.replace(rep, replace[rep])
			if foldername in EXCLUDES: folderdisplay = '[COLOR green][B][PROTECTED][/B][/COLOR] %s' % folderdisplay
			else: folderdisplay = '[COLOR red][B][REMOVE][/B][/COLOR] %s' % folderdisplay
			addFile(' %s' % folderdisplay, 'removedata', foldername, icon=icon, fanart=fanart, themeit=THEME2)
	else:
		addFile('No Addon data folder found.', '', themeit=THEME3)
	setView('files', 'viewType')

def enableAddons():
	addFile("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]", '', icon=ICONMAINT)
	fold = glob.glob(os.path.join(ADDONS, '*/'))
	x = 0
	for folder in sorted(fold, key = lambda x: x):
		foldername = os.path.split(folder[:-1])[1]
		if foldername in EXCLUDES: continue
		if foldername in DEFAULTPLUGINS: continue
		addonxml = os.path.join(folder, 'addon.xml')
		if os.path.exists(addonxml):
			x += 1
			fold   = folder.replace(ADDONS, '')[1:-1]
			f      = open(addonxml)
			a      = f.read().replace('\n','').replace('\r','').replace('\t','')
			match  = wiz.parseDOM(a, 'addon', ret='id')
			match2 = wiz.parseDOM(a, 'addon', ret='name')
			try:
				pluginid = match[0]
				name = match2[0]
			except:
				continue
			try:
				add    = xbmcaddon.Addon(id=pluginid)
				state  = "[COLOR green][Enabled][/COLOR]"
				goto   = "false"
			except:
				state  = "[COLOR red][Disabled][/COLOR]"
				goto   = "true"
				pass
			icon   = os.path.join(folder, 'icon.png') if os.path.exists(os.path.join(folder, 'icon.png')) else ICON
			fanart = os.path.join(folder, 'fanart.jpg') if os.path.exists(os.path.join(folder, 'fanart.jpg')) else FANART
			addFile("%s %s" % (state, name), 'toggleaddon', fold, goto, icon=icon, fanart=fanart)
			f.close()
	if x == 0:
		addFile("No Addons Found to Enable or Disable.", '', icon=ICONMAINT)
	setView('files', 'viewType')

def changeFeq():
	feq        = ['Every Startup', 'Every Day', 'Every Three Days', 'Every Weekly']
	change     = DIALOG.select("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]" % COLOR2, feq)
	if not change == -1: 
		wiz.setS('autocleanfeq', str(change))
		wiz.LogNotify('[COLOR %s]Auto Clean Up[/COLOR]' % COLOR1, '[COLOR %s]Fequency Now %s[/COLOR]' % (COLOR2, feq[change]))

def developer():
	addFile('Create QR Code',                      'createqr',              themeit=THEME1)
	addFile('Test Notifications',                  'testnotify',            themeit=THEME1)
	addFile('Test Update',                         'testupdate',            themeit=THEME1)
	addFile('Test First Run',                      'testfirst',             themeit=THEME1)
	addFile('Test First Run Settings',             'testfirstrun',          themeit=THEME1)
	setView('files', 'viewType')


def testTheme(path):
	zfile = zipfile.ZipFile(path)
	for item in zfile.infolist():
		wiz.log(str(item.filename))
		if '/settings.xml' in item.filename:
			return True
	return False

def testGui(path):
	zfile = zipfile.ZipFile(path)
	for item in zfile.infolist():
		if '/guisettings.xml' in item.filename:
			return True
	return False

def grabAddons(path):
	zfile = zipfile.ZipFile(path)
	addonlist = []
	for item in zfile.infolist():
		if str(item.filename).find('addon.xml') == -1: continue
		info = str(item.filename).split('/')
		if not info[-2] in addonlist:
			addonlist.append(info[-2])
	return addonlist


def toggleCache(state):
	cachelist = ['includevideo', 'includeall', 'includebob', 'includezen,' 'includephoenix', 'includespecto', 'includegenesis', 'includeexodus', 'includeonechan', 'includesalts', 'includesaltslite']
	titlelist = ['Include Video Addons', 'Include All Addons', 'Include Bob', 'Include Zen', 'Include Phoenix', 'Include Specto', 'Include Genesis', 'Include Exodus', 'Include One Channel', 'Include Salts', 'Include Salts Lite HD']
	if state in ['true', 'false']:
		for item in cachelist:#F%T&G
			wiz.setS(item, state)
	else:
		if not state in ['includevideo', 'includeall'] and wiz.getS('includeall') == 'true':
			try:
				item = titlelist[cachelist.index(state)]
				DIALOG.ok(ADDONTITLE, "[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]" % (COLOR2, COLOR1, COLOR1, item))
			except:
				wiz.LogNotify("[COLOR %s]Toggle Cache[/COLOR]" % COLOR1, "[COLOR %s]Invalid id: %s[/COLOR]" % (COLOR2, state))
		else:
			new = 'true' if wiz.getS(state) == 'false' else 'false'
			wiz.setS(state, new)

def playVideo(url):
	if 'watch?v=' in url:
		a, b = url.split('?')
		find = b.split('&')
		for item in find:
			if item.startswith('v='):
				url = item[2:]
				break
			else: continue
	elif 'embed' in url or 'youtu.be' in url:
		a = url.split('/')
		if len(a[-1]) > 5:
			url = a[-1]
		elif len(a[-2]) > 5:
			url = a[-2]
	wiz.log("YouTube URL: %s" % url)
	if wiz.getCond('System.HasAddon(plugin.video.youtube)') == 1:
		url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
		xbmc.Player().play(url)
	xbmc.sleep(2000)
	if xbmc.Player().isPlayingVideo() == 0:
		yt.PlayVideo(url)

def viewLogFile():
	mainlog = wiz.Grab_Log(True)
	oldlog  = wiz.Grab_Log(True, True)
	which = 0; logtype = mainlog
	if not oldlog == False and not mainlog == False:
		which = DIALOG.select(ADDONTITLE, ["View %s" % mainlog.replace(LOG, ""), "View %s" % oldlog.replace(LOG, "")])
		if which == -1: wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]View Log Cancelled![/COLOR]' % COLOR2); return
	elif mainlog == False and oldlog == False:
		wiz.LogNotify('[COLOR %s]View Log[/COLOR]' % COLOR1, '[COLOR %s]No Log File Found![/COLOR]' % COLOR2)
		return
	elif not mainlog == False: which = 0
	elif not oldlog == False: which = 1
	
	logtype = mainlog if which == 0 else oldlog
	msg     = wiz.Grab_Log(False) if which == 0 else wiz.Grab_Log(False, True)
	
	wiz.TextBox("%s - %s" % (ADDONTITLE, logtype), msg)

def errorList(file):
	errors = []
	a=open(file).read()
	b=a.replace('\n','[CR]').replace('\r','')
	match = re.compile("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall(b)
	for item in match:
		errors.append(item)
	return errors

def errorChecking(log=None, count=None, last=None):
	errors = []; error1 = []; error2 = [];
	if log == None:
		curr = wiz.Grab_Log(True, False)
		old = wiz.Grab_Log(True, True)
		if old == False and curr == False:
			if count == None: 
				wiz.LogNotify('[COLOR %s]View Error Log[/COLOR]' % COLOR1, '[COLOR %s]No Log File Found![/COLOR]' % COLOR2)
				return
			else:
				return 0
		if not curr == False: #F+T+G#
			error1 = errorList(curr)
		if not old == False: 
			error2 = errorList(old)
		if len(error2) > 0: 
			for item in error2: errors = [item] + errors
		if len(error1) > 0: 
			for item in error1: errors = [item] + errors
	else:
		error1 = errorList(log)
		if len(error1) > 0:
			for item in error1: errors = [item] + errors
	if not count == None:
		return len(errors)
	elif len(errors) > 0:
		if last == None:
			i = 0; string = ''
			for item in errors:
				i += 1
				string += "[B][COLOR red]ERROR NUMBER %s:[/B][/COLOR]%s\n" % (str(i), item.replace(HOME, '/').replace('                                        ', ''))
		else:
			string = "[B][COLOR red]Last Error in Log:[/B][/COLOR]%s\n" % (errors[0].replace(HOME, '/').replace('                                        ', ''))
		wiz.TextBox("%s: Errors in Log" % ADDONTITLE, string)
	else:
		wiz.LogNotify('[COLOR %s]View Error Log[/COLOR]' % COLOR1, '[COLOR %s]No Errors Found![/COLOR]' % COLOR2)

ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108

def LogViewer(default=None):
	class LogViewer(xbmcgui.WindowXMLDialog):
		def __init__(self,*args,**kwargs):
			self.default = kwargs['default']

		def onInit(self):
			self.title      = 101
			self.msg        = 102
			self.scrollbar  = 103
			self.upload     = 201
			self.kodi       = 202
			self.kodiold    = 203
			self.wizard     = 204 
			self.okbutton   = 205 
			f = open(self.default, 'r')
			self.logmsg = f.read()
			f.close()
			self.titlemsg = "%s: %s" % (ADDONTITLE, self.default.replace(LOG, '').replace(ADDONDATA, ''))
			self.showdialog()

		def showdialog(self):
			self.getControl(self.title).setLabel(self.titlemsg)
			self.getControl(self.msg).setText(wiz.highlightText(self.logmsg))
			self.setFocusId(self.scrollbar)
			
		def onClick(self, controlId):
			if   controlId == self.okbutton: self.close()
			elif controlId == self.upload: self.close(); uploadLog.Main()
			elif controlId == self.kodi:
				newmsg = wiz.Grab_Log(False)
				filename = wiz.Grab_Log(True)
				if newmsg == False:
					self.titlemsg = "%s: View Log Error" % ADDONTITLE
					self.getControl(self.msg).setText("Log File Does Not Exists!")
				else:
					self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
					self.getControl(self.title).setLabel(self.titlemsg)
					self.getControl(self.msg).setText(wiz.highlightText(newmsg))
					self.setFocusId(self.scrollbar)
			elif controlId == self.kodiold:  
				newmsg = wiz.Grab_Log(False, True)
				filename = wiz.Grab_Log(True, True)
				if newmsg == False:
					self.titlemsg = "%s: View Log Error" % ADDONTITLE
					self.getControl(self.msg).setText("Log File Does Not Exists!")
				else:
					self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(LOG, ''))
					self.getControl(self.title).setLabel(self.titlemsg)
					self.getControl(self.msg).setText(wiz.highlightText(newmsg))
					self.setFocusId(self.scrollbar)
			elif controlId == self.wizard:
				newmsg = wiz.Grab_Log(False, False, True)
				filename = wiz.Grab_Log(True, False, True)
				if newmsg == False:
					self.titlemsg = "%s: View Log Error" % ADDONTITLE
					self.getControl(self.msg).setText("Log File Does Not Exists!")
				else:
					self.titlemsg = "%s: %s" % (ADDONTITLE, filename.replace(ADDONDATA, ''))
					self.getControl(self.title).setLabel(self.titlemsg)
					self.getControl(self.msg).setText(wiz.highlightText(newmsg))
					self.setFocusId(self.scrollbar)
		
		def onAction(self, action):
			if   action == ACTION_PREVIOUS_MENU: self.close()
			elif action == ACTION_NAV_BACK: self.close()
	if default == None: default = wiz.Grab_Log(True)
	lv = LogViewer( "LogViewer.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', default=default)
	lv.doModal()
	del lv

def removeAddon(addon, name, over=False):
	if not over == False:
		yes = 1
	else: 
		yes = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Are you sure you want to delete the addon:'% COLOR2, 'Name: [COLOR %s]%s[/COLOR]' % (COLOR1, name), 'ID: [COLOR %s]%s[/COLOR][/COLOR]' % (COLOR1, addon), yeslabel='[B][COLOR green]Remove Addon[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]')
	if yes == 1:
		folder = os.path.join(ADDONS, addon)
		wiz.log("Removing Addon %s" % addon)
		wiz.cleanHouse(folder)
		xbmc.sleep(200)
		try: shutil.rmtree(folder)
		except Exception ,e: wiz.log("Error removing %s" % addon, xbmc.LOGNOTICE)
		removeAddonData(addon, name, over)
	if over == False:
		wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]%s Removed[/COLOR]" % (COLOR2, name))

def removeAddonData(addon, name=None, over=False):
	if addon == 'all':
		if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
			wiz.cleanHouse(ADDOND)
		else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
	elif addon == 'uninstalled':
		if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
			total = 0
			for folder in glob.glob(os.path.join(ADDOND, '*')):
				foldername = folder.replace(ADDOND, '').replace('\\', '').replace('/', '')
				if foldername in EXCLUDES: pass
				elif os.path.exists(os.path.join(ADDONS, foldername)): pass
				else: wiz.cleanHouse(folder); total += 1; wiz.log(folder); shutil.rmtree(folder)
			wiz.LogNotify('[COLOR %s]Clean up Uninstalled[/COLOR]' % COLOR1, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLOR2, total))
		else: wiz.LogNotify('[COLOR %s]Remove Addon Data[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
	elif addon == 'empty':
		if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]' % (COLOR2, COLOR1), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
			total = wiz.emptyfolder(ADDOND)
			wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLOR1, '[COLOR %s]%s Folders(s) Removed[/COLOR]' % (COLOR2, total))
		else: wiz.LogNotify('[COLOR %s]Remove Empty Folders[/COLOR]' % COLOR1, '[COLOR %s]Cancelled![/COLOR]' % COLOR2)
	else:
		addon_data = os.path.join(USERDATA, 'addon_data', addon)
		if addon in EXCLUDES:
			wiz.LogNotify("[COLOR %s]Protected Plugin[/COLOR]" % COLOR1, "[COLOR %s]Not allowed to remove Addon_Data[/COLOR]" % COLOR2)
		elif os.path.exists(addon_data):  
			if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you also like to remove the addon data for:[/COLOR]' % COLOR2, '[COLOR %s]%s[/COLOR]' % (COLOR1, addon), yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]', nolabel='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):
				wiz.cleanHouse(addon_data)
				try:
					shutil.rmtree(addon_data)
				except:
					wiz.log("Error deleting: %s" % addon_data)
			else: 
				wiz.log('Addon data for %s was not removed' % addon)
	wiz.refresh()

def restoreit(type):
	if type == 'build':
		x = freshStart('restore')
		if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Local Restore Cancelled[/COLOR]" % COLOR2); return
	if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
		wiz.skinToDefault('Restore Backup')
	wiz.restoreLocal(type)

def restoreextit(type):
	if type == 'build':
		x = freshStart('restore')
		if x == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]External Restore Cancelled[/COLOR]" % COLOR2); return
	wiz.restoreExternal(type)

def buildVideo(name):
	if wiz.workingURL(BUILDFILE) == True:
		videofile = wiz.checkBuild(name, 'preview')
		if videofile and not videofile == 'http://': playVideo(videofile)
		else: wiz.log("[%s]Unable to find url for video preview" % name)
	else: wiz.log("Build text file not working: %s" % WORKINGURL)
	

		
		
def dependsList(plugin):
	addonxml = os.path.join(ADDONS, plugin, 'addon.xml')
	if os.path.exists(addonxml):
		source = open(addonxml,mode='r'); link = source.read(); source.close(); 
		match  = wiz.parseDOM(link, 'import', ret='addon')
		items  = []
		for depends in match:
			if not 'xbmc.python' in depends:
				items.append(depends)
		return items
	return []


###########################
###### Fresh Install ######
###########################
def freshStart(install=None, over=False):
	if KEEPTRAKT == 'true':
		traktit.autoUpdate('all')
		wiz.setS('traktlastsave', str(THREEDAYS))
	if KEEPREAL == 'true':
		debridit.autoUpdate('all')
		wiz.setS('debridlastsave', str(THREEDAYS))
	if KEEPLOGIN == 'true':
		loginit.autoUpdate('all')
		wiz.setS('loginlastsave', str(THREEDAYS))
	if over == True: yes_pressed = 1
	elif install == 'restore': yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your" % COLOR2, "Kodi configuration to default settings", "Before installing the local backup?[/COLOR]", nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
	elif install: yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your" % COLOR2, "Kodi configuration to default settings", "Before installing [COLOR %s]%s[/COLOR]?" % (COLOR1, install), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
	else: yes_pressed=DIALOG.yesno(ADDONTITLE, "[COLOR %s]Do you wish to restore your" % COLOR2, "Kodi configuration to default settings?[/COLOR]", nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Continue[/COLOR][/B]')
	if yes_pressed:
		if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
			swap = wiz.skinToDefault('Fresh Install')
			if swap == False: return False
			xbmc.sleep(1000)
		if not wiz.currSkin() in ['skin.confluence', 'skin.estuary']:
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Fresh Install: Skin Swap Failed![/COLOR]' % COLOR2)
			return
		wiz.addonUpdates('set')
		xbmcPath=os.path.abspath(HOME)
		DP.create(ADDONTITLE,"[COLOR %s]Calculating files and folders" % COLOR2,'', 'Please Wait![/COLOR]')
		total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0
		DP.update(0, "[COLOR %s]Gathering Excludes list." % COLOR2)
		EXCLUDES.append('My_Builds')
		EXCLUDES.append('archive_cache')
		if KEEPREPOS == 'true':
			repos = glob.glob(os.path.join(ADDONS, 'repo*/'))
			for item in repos:
				repofolder = os.path.split(item[:-1])[1]
				if not repofolder == EXCLUDES:
					EXCLUDES.append(repofolder)
		if KEEPSUPER == 'true':
			EXCLUDES.append('plugin.program.super.favourites')
		if KEEPWHITELIST == 'true':
			pvr = ''
			whitelist = wiz.whiteList('read')
			if len(whitelist) > 0:
				for item in whitelist:
					try: name, id, fold = item
					except: pass
					if fold.startswith('pvr'): pvr = id 
					depends = dependsList(fold)
					for plug in depends:
						if not plug in EXCLUDES:
							EXCLUDES.append(plug)
						depends2 = dependsList(plug)
						for plug2 in depends2:
							if not plug2 in EXCLUDES:
								EXCLUDES.append(plug2)
					if not fold in EXCLUDES:
						EXCLUDES.append(fold)
				if not pvr == '': wiz.setS('pvrclient', fold)
		if wiz.getS('pvrclient') == '':
			for item in EXCLUDES:
				if item.startswith('pvr'):
					wiz.setS('pvrclient', item)
		DP.update(0, "[COLOR %s]Clearing out files and folders:" % COLOR2)
		latestAddonDB = wiz.latestDB('Addons')
		for root, dirs, files in os.walk(xbmcPath,topdown=True):
			dirs[:] = [d for d in dirs if d not in EXCLUDES]
			for name in files:
				del_file += 1
				fold = root.replace('/','\\').split('\\')
				x = len(fold)-1
				if name == 'sources.xml' and fold[-1] == 'userdata' and KEEPSOURCES == 'true': wiz.log("Keep Sources: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'favourites.xml' and fold[-1] == 'userdata' and KEEPFAVS == 'true': wiz.log("Keep Favourites: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'profiles.xml' and fold[-1] == 'userdata' and KEEPPROFILES == 'true': wiz.log("Keep Profiles: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name == 'advancedsettings.xml' and fold[-1] == 'userdata' and KEEPADVANCED == 'true':  wiz.log("Keep Advanced Settings: %s" % os.path.join(root, name), xbmc.LOGNOTICE)
				elif name in LOGFILES: wiz.log("Keep Log File: %s" % name, xbmc.LOGNOTICE)
				elif name.endswith('.db'):
					try:
						if name == latestAddonDB and KODIV >= 17: wiz.log("Ignoring %s on v%s" % (name, KODIV), xbmc.LOGNOTICE)
						else: os.remove(os.path.join(root,name))
					except Exception, e: 
						if not name.startswith('Textures13'):
							wiz.log('Failed to delete, Purging DB', xbmc.LOGNOTICE)
							wiz.log("-> %s" % (str(e)), xbmc.LOGNOTICE)
							wiz.purgeDb(os.path.join(root,name))
				else:
					DP.update(int(wiz.percentage(del_file, total_files)), '', '[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]' % (COLOR2, COLOR1, name), '')
					try: os.remove(os.path.join(root,name))
					except Exception, e: 
						wiz.log("Error removing %s" % os.path.join(root, name), xbmc.LOGNOTICE)
						wiz.log("-> / %s" % (str(e)), xbmc.LOGNOTICE)
			if DP.iscanceled(): 
				DP.close()
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Fresh Start Cancelled[/COLOR]" % COLOR2)
				return False
		for root, dirs, files in os.walk(xbmcPath,topdown=True):
			dirs[:] = [d for d in dirs if d not in EXCLUDES]
			for name in dirs:
				DP.update(100, '', 'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]' % (COLOR1, name), '')
				if name not in ["Database","userdata","temp","addons","addon_data"]:
					shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
			if DP.iscanceled(): 
				DP.close()
				wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Fresh Start Cancelled[/COLOR]" % COLOR2)
				return False
		DP.close()
		wiz.clearS('build')
		if over == True:
			return True
		elif install == 'restore': 
			return True
		elif install: 
			buildWizard(install, 'normal', over=True)
		else:
			yes = DIALOG.yesno(ADDONTITLE, "[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]" % (COLOR2, COLOR1, COLOR1), yeslabel="[B][COLOR red]Reload Profile[/COLOR][/B]", nolabel="[B][COLOR green]Force Close[/COLOR][/B]")
			if yes ==1:
				wiz.reloadFix('remove addon')
			else: wiz.addonUpdates('reset'); wiz.killxbmc(True)
	else: 
		if not install == 'restore':
			wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]Fresh Install: Cancelled![/COLOR]' % COLOR2)
			wiz.refresh()

#############################
###DELETE CACHE##############
####THANKS GUYS @ NaN #######
def clearCache():
	if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Clear Cache[/COLOR][/B]'):
		wiz.clearCache()


def clearArchive():
	if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear the \'Archive_Cache\' folder?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Yes Clear[/COLOR][/B]'):
		wiz.clearArchive()

def totalClean():
	if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache, packages and thumbnails?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]Cancel Process[/COLOR][/B]',yeslabel='[B][COLOR green]Clean All[/COLOR][/B]'):
		wiz.clearCache()
		wiz.clearPackages('total')
		clearThumb('total')

def clearThumb(type=None):
	latest = wiz.latestDB('Textures')
	if not type == None: choice = 1
	else: choice = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the %s and Thumbnails folder?' % (COLOR2, latest), "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR green]Delete Thumbs[/COLOR][/B]')
	if choice == 1:
		try: wiz.removeFile(os.join(DATABASE, latest))
		except: wiz.log('Failed to delete, Purging DB.'); wiz.purgeDb(latest)
		wiz.removeFolder(THUMBS)
		#if not type == 'total': wiz.killxbmc()
	else: wiz.log('Clear thumbnames cancelled')
	wiz.redoThumbs()

def purgeDb():
	DB = []; display = []
	for dirpath, dirnames, files in os.walk(HOME):
		for f in fnmatch.filter(files, '*.db'):
			if f != 'Thumbs.db':
				found = os.path.join(dirpath, f)
				DB.append(found)
				dir = found.replace('\\', '/').split('/')
				display.append('(%s) %s' % (dir[len(dir)-2], dir[len(dir)-1]))
	if KODIV >= 16: 
		choice = DIALOG.multiselect("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
		if choice == None: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
		elif len(choice) == 0: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
		else: 
			for purge in choice: wiz.purgeDb(DB[purge])
	else:
		choice = DIALOG.select("[COLOR %s]Select DB File to Purge[/COLOR]" % COLOR2, display)
		if choice == -1: wiz.LogNotify("[COLOR %s]Purge Database[/COLOR]" % COLOR1, "[COLOR %s]Cancelled[/COLOR]" % COLOR2)
		else: wiz.purgeDb(DB[purge])

##########################
### DEVELOPER MENU #######
##########################
def testnotify():
	url = wiz.workingURL(NOTIFICATION)
	if url == True:
		try:
			id, msg = wiz.splitNotify(NOTIFICATION)
			if id == False: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Notification: Not Formated Correctly[/COLOR]" % COLOR2); return
			notify.notification(msg, True)
		except Exception, e:
			wiz.log("Error on Notifications Window: %s" % str(e), xbmc.LOGERROR)
	else: wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Invalid URL for Notification[/COLOR]" % COLOR2)

def testupdate():
	if BUILDNAME == "":
		notify.updateWindow()
	else:
		notify.updateWindow(BUILDNAME, BUILDVERSION, BUILDLATEST, wiz.checkBuild(BUILDNAME, 'icon'), wiz.checkBuild(BUILDNAME, 'fanart'))

def testfirst():
	notify.firstRun()

def testfirstRun():
	notify.firstRunSettings()

###########################
## Making the Directory####
###########################
def Add_Directory_Item(handle, url, listitem, isFolder):
	xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder)
	
def addDir2(name,url,mode,iconimage,fanart):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": name } )
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
	
def addFolder(type,name,url,mode,iconimage = '',FanArt = '',video = '',description = ''):
	if type != 'folder2' and type != 'addon':
		if len(iconimage) > 0:
			iconimage = Images + iconimage
		else:##F#T#G##
			iconimage = 'DefaultFolder.png'
	if type == 'addon':
		if len(iconimage) > 0:
			iconimage = iconimage
		else:
			iconimage = 'none'
	if FanArt == '':
		FanArt = FanArt
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&FanArt="+urllib.quote_plus(FanArt)+"&video="+urllib.quote_plus(video)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
	liz.setProperty( "FanArt_Image", FanArt )
	liz.setProperty( "Build.Video", video )
	if (type=='folder') or (type=='folder2') or (type=='tutorial_folder') or (type=='news_folder'):
		ok=Add_Directory_Item(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	else:
		ok=Add_Directory_Item(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addDir(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
	u = sys.argv[0]
	if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
	if not name == None: u += "&name="+urllib.quote_plus(name)
	if not url == None: u += "&url="+urllib.quote_plus(url)
	ok=True
	if themeit: display = themeit % display
	liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
	liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
	liz.setProperty( "Fanart_Image", fanart )
	if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addFile(display, mode=None, name=None, url=None, menu=None, description=ADDONTITLE, overwrite=True, fanart=FANART, icon=ICON, themeit=None):
	u = sys.argv[0]
	if not mode == None: u += "?mode=%s" % urllib.quote_plus(mode)
	if not name == None: u += "&name="+urllib.quote_plus(name)
	if not url == None: u += "&url="+urllib.quote_plus(url)
	ok=True
	if themeit: display = themeit % display
	liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
	liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": description} )
	liz.setProperty( "Fanart_Image", fanart )
	if not menu == None: liz.addContextMenuItems(menu, replaceItems=overwrite)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]

		return param

params=get_params()
url=None
name=None
mode=None

try:     mode=urllib.unquote_plus(params["mode"])
except:  pass
try:     name=urllib.unquote_plus(params["name"])
except:  pass
try:     url=urllib.unquote_plus(params["url"])
except:  pass

wiz.log('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]' % (VERSION, mode if not mode == '' else None, name, url))

def setView(content, viewType):
	if wiz.getS('auto-view')=='true':
		views = wiz.getS(viewType)
		if views == '50' and KODIV >= 17 and SKIN == 'skin.estuary': views = '55'
		if views == '500' and KODIV >= 17 and SKIN == 'skin.estuary': views = '50'
		wiz.ebi("Container.SetViewMode(%s)" %  views)

if   mode=='enableaddons'             : enableAddons()

elif mode=='wizardupdate'   : wiz.wizardUpdate()
elif mode=='maint'          : maintMenu(name)
elif mode=='kodi17fix'      : wiz.kodi17Fix()
elif mode=='unknownsources' : skinSwitch.swapUS()
elif mode=='advancedsetting': advancedWindow(name)
elif mode=='autoadvanced1'  : showAutoAdvanced1(); wiz.refresh()
elif mode=='removeadvanced' : removeAdvanced(); wiz.refresh()
elif mode=='asciicheck'     : wiz.asciiCheck()
elif mode=='oldThumbs'      : wiz.oldThumbs()
elif mode=='clearbackup'    : wiz.cleanupBackup()
elif mode=='convertpath'    : wiz.convertSpecial(HOME)
elif mode=='currentsettings': viewAdvanced()
elif mode=='fullclean'      : totalClean(); wiz.refresh()
elif mode=='clearcache'     : clearCache(); wiz.refresh()
elif mode=='clearpackages'  : wiz.clearPackages(); wiz.refresh()
elif mode=='clearcrash'     : wiz.clearCrash(); wiz.refresh()
elif mode=='clearthumb'     : clearThumb(); wiz.refresh()
elif mode=='cleararchive'   : clearArchive(); wiz.refresh()
elif mode=='checksources'   : wiz.checkSources(); wiz.refresh()
elif mode=='checkrepos'     : wiz.checkRepos(); wiz.refresh()
elif mode=='freshstart'     : freshStart()
elif mode=='forceupdate'    : wiz.forceUpdate()
elif mode=='forceprofile'   : wiz.reloadProfile(wiz.getInfo('System.ProfileName'))
elif mode=='forceclose'     : wiz.killxbmc()
elif mode=='forceskin'      : wiz.ebi("ReloadSkin()"); wiz.refresh()
elif mode=='hidepassword'   : wiz.hidePassword()
elif mode=='unhidepassword' : wiz.unhidePassword()
elif mode=='enableaddons'   : enableAddons()
elif mode=='toggleaddon'    : wiz.toggleAddon(name, url); wiz.refresh()
elif mode=='togglecache'    : toggleCache(name); wiz.refresh()
elif mode=='toggleadult'    : wiz.toggleAdult(); wiz.refresh()
elif mode=='changefeq'      : changeFeq(); wiz.refresh()
elif mode=='uploadlog'      : uploadLog.Main()
elif mode=='viewlog'        : LogViewer()
elif mode=='viewwizlog'     : LogViewer(WIZLOG)
elif mode=='viewerrorlog'   : errorChecking()
elif mode=='viewerrorlast'  : errorChecking(last=True)
elif mode=='clearwizlog'    : f = open(WIZLOG, 'w'); f.close(); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Wizard Log Cleared![/COLOR]" % COLOR2)
elif mode=='purgedb'        : purgeDb()
elif mode=='fixaddonupdate' : fixUpdate()
elif mode=='removeaddons'   : removeAddonMenu()
elif mode=='removeaddon'    : removeAddon(name)
elif mode=='removeaddondata': removeAddonDataMenu()
elif mode=='removedata'     : removeAddonData(name)
elif mode=='resetaddon'     : total = wiz.cleanHouse(ADDONDATA, ignore=True); wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Addon_Data reset[/COLOR]" % COLOR2)
elif mode=='systeminfo'     : systemInfo()
elif mode=='restorezip'     : restoreit('build')
elif mode=='restoregui'     : restoreit('gui')
elif mode=='restoreaddon'   : restoreit('addondata')
elif mode=='restoreextzip'  : restoreextit('build')
elif mode=='restoreextgui'  : restoreextit('gui')
elif mode=='restoreextaddon': restoreextit('addondata')
elif mode=='writeadvanced'  : writeAdvanced(name, url)
elif mode=='speedtest'      : speedTest()
elif mode=='speed'          : speed(); wiz.refresh()# changed from runspeedtest = build conflict
elif mode=='clearspeedtest' : clearSpeedTest(); wiz.refresh()
elif mode=='viewspeedtest'  : viewSpeedTest(name); wiz.refresh()

elif mode=='apk'            : apkMenu(name, url)
elif mode=='apkscrape'      : apkScraper(name)
elif mode=='apkinstall'     : apkInstaller(name, url)
elif mode=='apkinstall1'    : apkInstaller1(name, url)

elif mode=='youtube'        : youtubeMenu(name, url)
elif mode=='viewVideo'      : playVideo(url)

elif mode=='addons'         : addonMenu(name, url)
elif mode=='addonpack'      : packInstaller(name, url)
elif mode=='skinpack'       : skinInstaller(name, url)
elif mode=='addoninstall'   : addonInstaller(name, url)

elif mode=='savedata'       : saveMenu()
elif mode=='togglesetting'  : wiz.setS(name, 'false' if wiz.getS(name) == 'true' else 'true'); wiz.refresh()
elif mode=='managedata'     : manageSaveData(name)
elif mode=='whitelist'      : wiz.whiteList(name)

elif mode=='trakt'          : traktMenu()
elif mode=='savetrakt'      : traktit.traktIt('update',      name)
elif mode=='restoretrakt'   : traktit.traktIt('restore',     name)
elif mode=='addontrakt'     : traktit.traktIt('clearaddon',  name)
elif mode=='cleartrakt'     : traktit.clearSaved(name)
elif mode=='authtrakt'      : traktit.activateTrakt(name); wiz.refresh()
elif mode=='updatetrakt'    : traktit.autoUpdate('all')
elif mode=='importtrakt'    : traktit.importlist(name); wiz.refresh()

elif mode=='contact'        : notify.contact(CONTACT)
elif mode=='settings'       : wiz.openS(name); wiz.refresh()
elif mode=='forcetext'      : wiz.forceText()
elif mode=='opensettings'   : id = eval(url.upper()+'ID')[name]['plugin']; addonid = wiz.addonId(id); addonid.openSettings(); wiz.refresh()

elif mode=='developer'      : developer()
elif mode=='converttext'    : wiz.convertText()
elif mode=='createqr'       : wiz.createQR()
elif mode=='testnotify'     : testnotify()
elif mode=='testupdate'     : testupdate()
elif mode=='testfirst'      : testfirst()
elif mode=='testfirstrun'   : testfirstRun()

###FTG MODS###
elif mode=='backup'         : backup()
elif mode=='addon'          : addon()
elif mode=='misc'           : misc()
elif mode=='tweaks'         : tweaks()
elif mode=='net'            : net_tools()
elif mode=='viewIP'         : viewIP()
elif mode=='backup'         : backup()
elif mode=='FavsMenu'       : FavsMenu()
elif mode=='savefav'        : wiz.BACKUPFAV()
elif mode=='restorefav'     : wiz.RESTOREFAV()
elif mode=='clearfav'       : wiz.DELFAV()
elif mode=='autoadvanced'   : notify.autoConfig2(); wiz.refresh()
elif mode=='autoconfig'     : autoconfig()

if __name__ == '__main__':
    window = MaintWindow('FTG Maint')
    window.doModal()
    del window