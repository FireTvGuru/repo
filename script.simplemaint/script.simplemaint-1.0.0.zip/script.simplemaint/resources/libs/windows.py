################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import urllib2,urllib
import re,json
import time
from resources.libs import source, addonwindow as pyxbmct
from datetime import date, datetime, timedelta

ADDON_ID       = 'script.simplemaint'
ADDONTITLE     = '[COLOR yellow]-[COLOR blue][B]FTG Simple Maint[/B][COLOR yellow]-[/COLOR]'
ADDON          = source.addonId(ADDON_ID)
ADDONPATH      = source.addonInfo(ADDON_ID,'path')

DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME             = xbmc.translatePath('special://home/')
LOG              = xbmc.translatePath('special://logpath/')
PROFILE          = xbmc.translatePath('special://profile/')
TEMPDIR          = xbmc.translatePath('special://temp')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
FANART         = os.path.join(ADDONPATH,   'fanart.jpg')
ICON           = os.path.join(ADDONPATH,   'icon.png')
ART            = os.path.join(ADDONPATH,   'resources', 'art')
SKINFOLD       = os.path.join(ADDONPATH,   'resources', 'skins', 'DefaultSkin', 'media')
ADVANCED       = os.path.join(USERDATA,  'advancedsettings.xml')

TODAY          = date.today()
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
TOMORROW       = TODAY + timedelta(days=1)
THREEDAYS      = TODAY + timedelta(days=3)

COLOR1         = 'blue'
COLOR2         = 'yellow'
COLOR3         = 'red'
COLOR4         = 'snow'
COLOR5         = 'lime'




ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108

def artwork(file):
	if   file == 'button': return os.path.join(SKINFOLD, 'Button', 'button-focus_lightblue.png'), os.path.join(SKINFOLD, 'Button', 'button-focus_grey.png')
	elif file == 'radio' : return os.path.join(SKINFOLD, 'RadioButton', 'MenuItemFO.png'), os.path.join(SKINFOLD, 'RadioButton', 'MenuItemNF.png'), os.path.join(SKINFOLD, 'RadioButton', 'radiobutton-focus.png'), os.path.join(SKINFOLD, 'RadioButton', 'radiobutton-nofocus.png')
	elif file == 'slider': return os.path.join(SKINFOLD, 'Slider', 'osd_slider_nib.png'), os.path.join(SKINFOLD, 'Slider', 'osd_slider_nibNF.png'), os.path.join(SKINFOLD, 'Slider', 'slider1.png'), os.path.join(SKINFOLD, 'Slider', 'slider1.png')

	
def autoConfig(msg='', TxtColor='0xFFFFFFFF', Font='font10', BorderWidth=10):
	class MyWindow(xbmcgui.WindowDialog):
		scr={};
		def __init__(self,msg='',L=0,T=0,W=1280,H=720,TxtColor='0xFFFFFFFF',Font='font10',BorderWidth=10):
			buttonfocus, buttonnofocus = artwork('button')
			self.BG=xbmcgui.ControlImage(L+BorderWidth,T+BorderWidth,W-(BorderWidth*2),H-(BorderWidth*2), FANART, aspectRatio=0)
			self.addControl(self.BG)
			top = T+BorderWidth
			leftside = L+BorderWidth
			rightside = L+(W/2)-(BorderWidth*2)
			
			header = '[COLOR %s]Quick Advanced Settings Configurator[/COLOR]' % (COLOR3)
			self.Header=xbmcgui.ControlLabel(L, top, W, 30, header, font='font13', textColor=TxtColor, alignment=0x00000002)
			self.addControl(self.Header)
			top += 30+BorderWidth
			
			#####Video Cache Size####
			freeMemory = int(float(source.getInfo('System.Memory(free)')[:-2])*.33)
			recMemory = int(float(source.getInfo('System.Memory(free)')[:-2])*.23)

			self.videomin = 0; self.videomax = freeMemory if freeMemory < 2000 else 2000
			self.recommendedVideo = recMemory if recMemory < 500 else 500; self.currentVideo = self.recommendedVideo
			current1 = '[COLOR %s]Video Cache Size[/COLOR]=[COLOR %s]%s MB[/COLOR]' % (COLOR1, COLOR2, self.currentVideo)
			recommended1 = '[COLOR %s]Video Cache Size:[/COLOR] [COLOR %s]%s MB[/COLOR]' % (COLOR1, COLOR5, self.recommendedVideo)
			
			####CURL Timeout/CURL Low Speed####
			self.curlmin = 0; self.curlmax = 20
			self.recommendedCurl = 10; self.currentCurl = self.recommendedCurl
			curlpos = source.percentage(self.currentCurl, self.curlmax)
			recommended2 = '[COLOR %s]CURL Timeout/CURL Low Speed:[/COLOR] [COLOR %s]%ss[/COLOR]' % (COLOR1, COLOR5, self.recommendedCurl)
			
			########Read Buffer Factor#####
			self.readmin = 0; self.readmax = 10
			self.recommendedRead = 5; self.currentRead = self.recommendedRead
			readpos = source.percentage(self.currentRead, self.readmax)
			recommended3 = '[COLOR %s]Read Buffer Factor:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR5, self.recommendedRead)
			
			######Buffer Mode#####
			recommended4 = '[COLOR %s]Buffer Mode:[/COLOR] [COLOR %s]2[/COLOR]' %(COLOR1, COLOR5)

			
			####BOX##
			msgbox='[COLOR %s]These settings will be written to the advancesettings.xml[/COLOR]\r\n\r\n%s\r\n%s\r\n%s\r\n%s' %(COLOR4, recommended4, recommended1, recommended3, recommended2)
			self.box=xbmcgui.ControlTextBox(L+25,T+50,W,H, font='font14')
			self.addControl(self.box)
			self.box.setText(msgbox)
			
			####Buttons###
			
			
			
			self.buttonWrite=xbmcgui.ControlButton(leftside,T+H-40-BorderWidth,(W/2)-(BorderWidth*2),35,"Write File",textColor="0xFF000000",focusedColor="0xFF000000",alignment=2,focusTexture=buttonfocus,noFocusTexture=buttonnofocus)
			self.buttonCancel=xbmcgui.ControlButton(rightside+BorderWidth*2,T+H-40-BorderWidth,(W/2)-(BorderWidth*2),35,"Cancel",textColor="0xFF000000",focusedColor="0xFF000000",alignment=2,focusTexture=buttonfocus,noFocusTexture=buttonnofocus)
			
			self.addControl(self.buttonWrite); self.addControl(self.buttonCancel)
			self.setFocus(self.buttonCancel)
			
			self.buttonWrite.controlLeft(self.buttonCancel); self.buttonWrite.controlRight(self.buttonCancel); self.buttonCancel.controlLeft(self.buttonWrite); self.buttonCancel.controlRight(self.buttonWrite)
			

			
		def doExit(self):
			self.CloseWindow()
			
		def updateCurrent(self, control):
			if control == self.videoCacheSize:
				self.currentVideo = (self.videomax)*self.videoCacheSize.getPercent()/100
				current = '[COLOR %s]Current:[/COLOR] [COLOR %s]%s MB[/COLOR]' % (COLOR1, COLOR2, int(self.currentVideo))
				self.currentVideo1.setText(current)
				
			elif control == self.CURLTimeout:
				self.currentCurl = (self.curlmax)*self.CURLTimeout.getPercent()/100
				current = '[COLOR %s]Current:[/COLOR] [COLOR %s]%ss[/COLOR]' % (COLOR1, COLOR2, int(self.currentCurl))
				self.currentCurl2.setText(current)
				
			elif control == self.readBufferFactor:
				self.currentRead = (self.readmax)*self.readBufferFactor.getPercent()/100
				current = '[COLOR %s]Current:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, int(self.currentRead))
				self.currentRead3.setText(current)
				

		def doWrite(self):

			buffermode = 2

			if os.path.exists(ADVANCED):
				choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]There is currently an active [COLOR %s]AdvancedSettings.xml[/COLOR], would you like to remove it and continue?[/COLOR]" % (COLOR2, COLOR1), yeslabel="[B][COLOR green]Remove Settings[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Write[/COLOR][/B]")
				if choice == 0: return
				try: os.remove(ADVANCED)
				except: f = open(ADVANCED, 'w'); f.close()
			if KODIV < 17:
				with open(ADVANCED, 'w+') as f:
					f.write('<advancedsettings>\n')
					f.write('	<network>\n')
					f.write('		<buffermode>%s</buffermode>\n' % buffermode)
					f.write('		<cachemembuffersize>%s</cachemembuffersize>\n' % int(self.currentVideo*1024*1024))
					f.write('		<readbufferfactor>%s</readbufferfactor>\n' % self.currentRead)
					f.write('		<curlclienttimeout>%s</curlclienttimeout>\n' % self.currentCurl)
					f.write('		<curllowspeedtime>%s</curllowspeedtime>\n' % self.currentCurl)
					f.write('	</network>\n')
					f.write('</advancedsettings>\n')
				f.close()
			else:
				with open(ADVANCED, 'w+') as f:
					f.write('<advancedsettings>\n')
					f.write('	<cache>\n')
					f.write('		<buffermode>%s</buffermode>\n' % buffermode)
					f.write('		<memorysize>%s</memorysize>\n' % int(self.currentVideo*1024*1024))
					f.write('		<readfactor>%s</readfactor>\n' % self.currentRead)
					f.write('	</cache>\n')
					f.write('	<network>\n')
					f.write('		<curlclienttimeout>%s</curlclienttimeout>\n' % self.currentCurl)
					f.write('		<curllowspeedtime>%s</curllowspeedtime>\n' % self.currentCurl)
					f.write('	</network>\n')
					f.write('</advancedsettings>\n')
				f.close()
				source.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), '[COLOR %s]AdvancedSettings.xml have been written[/COLOR]' % COLOR2)
			self.CloseWindow()
			
		def onControl(self, control):
			if   control==self.buttonWrite: self.doWrite()
			elif control==self.buttonCancel:  self.doExit()

		def onAction(self, action):
			try: F=self.getFocus()
			except: F=False
			if action == ACTION_PREVIOUS_MENU:  self.doExit()
			elif action == ACTION_NAV_BACK:       self.doExit()
			
		def CloseWindow(self): self.close()

	maxW=1280; maxH=720; W=int(700); H=int(350); L=int((maxW-W)/2); T=int((maxH-H)/2); 
	TempWindow=MyWindow(L=L,T=T,W=W,H=H,TxtColor=TxtColor,Font=Font,BorderWidth=BorderWidth); 
	TempWindow.doModal() 
	del TempWindow


	
def speedTest(img):
	class speedTest(xbmcgui.WindowXMLDialog):
		def __init__(self,*args,**kwargs):
			self.imgfile    = kwargs['img']
		
		def onInit(self):
			self.imagespeed = 101
			self.button     = 201
			self.showdialog()
			
		def showdialog(self):
			self.setFocus(self.getControl(self.button))
			self.getControl(self.imagespeed).setImage(self.imgfile)

		def onClick(self,controlID): self.CloseWindow()

		def onAction(self,action):
			if action in [ACTION_PREVIOUS_MENU, ACTION_BACKSPACE, ACTION_NAV_BACK, ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK, ACTION_MOUSE_LONG_CLICK]: self.CloseWindow()

		def CloseWindow(self):
			self.close()

		def set_navigation(self):
		# Set navigation between controls
			self.setFocus(self.close_button)
	
	popup = speedTest('SpeedTest.xml', ADDON.getAddonInfo('path'), 'DefaultSkin', img=img)
	popup.doModal()
	del popup
	


def firstRun():
	class firstRun(xbmcgui.WindowXMLDialog):
		def __init__(self,*args,**kwargs):
			self.title1 =  ADDONTITLE
		def onInit(self):
			self.title      = 101
			self.okbutton   = 201
			self.auto       = 301
			self.manual     = 302
			self.cache      = 303
			self.showdialog()
			self.controllist     = [self.auto, self.manual, self.cache]
			self.controlsettings = ['autoclean', 'manclean','clearcache']
			
			for item in self.controllist:
				if source.getS(self.controlsettings[self.controllist.index(item)]) == 'true':
					self.getControl(item).setSelected(True)

		def showdialog(self):
			self.getControl(self.title).setLabel(self.title1)
			self.setFocus(self.getControl(self.okbutton))
			
		def onClick(self, controlId):
			if controlId == self.okbutton:
				self.close()

				for item in self.controllist:
					at = self.controllist.index(item)
					if self.getControl(item).isSelected(): source.setS(self.controlsettings[at], 'true')
					else: source.setS(self.controlsettings[at], 'false')

	fr = firstRun( "FirstRun.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin')
	fr.doModal()
	del fr

	
def net_info():
	import re
	import json
	from urllib2 import urlopen
	infoLabel = ['Network.IPAddress',
				 'Network.MacAddress',]
	data      = []; x = 0
	for info in infoLabel:
		temp = source.getInfo(info)
		y = 0
		while temp == "Busy" and y < 10:
			temp = source.getInfo(info); y += 1; xbmc.sleep(200)
		data.append(temp)
		x += 1
	try:
		url = 'http://extreme-ip-lookup.com/json/'
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
		response = urllib2.urlopen(req)
		FTG = json.load(response)
	except:
		url = 'http://ip-api.com/json'
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
		response = urllib2.urlopen(req)
		FTG = json.load(response)
	mac = data[1]
	inter_ip = data[0]
	ip=FTG['query']
	isp=FTG['org']
	city = FTG['city']
	country=FTG['country']
	state=FTG['region']
	return mac,inter_ip,ip,city,state,country,isp
	
mac,inter_ip,ip,city,state,country,isp=net_info()
DES_T_COLOR = 'blue'
DESCOLOR = 'orange'

def SHOWNET():
	class FTG(xbmcgui.WindowXMLDialog):
		def __init__(self,*args,**kwargs):
			
			self.title    ='[COLOR yellow]-[COLOR blue][B]FTG IP Stats[/B][COLOR yellow]-[/COLOR]'
			self.MAC      ='[COLOR %s]Mac:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR, mac)
			self.INTER_IP ='[COLOR %s]Internal IP: [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,inter_ip)
			self.IP       ='[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,ip)
			self.CITY     ='[COLOR %s]City:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,city)
			self.STATE    ='[COLOR %s]State:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,state)
			self.COUNTRY  ='[COLOR %s]Country:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,country)
			self.ISP      ='[COLOR %s]ISP:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,isp)
		
		def onInit(self):
			self.header    = 100
			self.vMAC      = 101
			self.vINTER_IP = 102
			self.vIP       = 103
			self.vCITY     = 104
			self.vSTATE    = 105
			self.vCOUNTRY  = 106
			self.vISP      = 107
			self.show_net()
			
		def show_net(self):
			self.getControl(self.header).setLabel(self.title)
			self.getControl(self.vMAC).setText(self.MAC)
			self.getControl(self.vINTER_IP).setText(self.INTER_IP)
			self.getControl(self.vIP).setText(self.IP)
			self.getControl(self.vCITY).setText(self.CITY)
			self.getControl(self.vSTATE).setText(self.STATE)
			self.getControl(self.vCOUNTRY).setText(self.COUNTRY)
			self.getControl(self.vISP).setText(self.ISP)

		def onClick(self,controlID): self.CloseWindow()

		def onAction(self,action):
			if action in [ACTION_PREVIOUS_MENU, ACTION_BACKSPACE, ACTION_NAV_BACK, ACTION_SELECT_ITEM, ACTION_MOUSE_LEFT_CLICK, ACTION_MOUSE_LONG_CLICK]: self.CloseWindow()

		def CloseWindow(self):
			self.close()
	
	ipstats = FTG('IpStats.xml', ADDON.getAddonInfo('path'), 'DefaultSkin')
	ipstats.doModal()
	del ipstats 