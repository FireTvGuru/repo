

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys
from resources.libs import source,windows,speedtest, addonwindow as pyxbmct


ADDON_ID         = 'script.simplemaint'
ADDONTITLE       = '[COLOR yellow]-[COLOR blue][B]FTG Simple Maint[/B][COLOR yellow]-[/COLOR]'
HOME             = xbmc.translatePath('special://home/')
LOG              = xbmc.translatePath('special://logpath/')
PROFILE          = xbmc.translatePath('special://profile/')
TEMPDIR          = xbmc.translatePath('special://temp')

ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PACKAGES         = os.path.join(ADDONS,    'packages')
THUMBS           = os.path.join(USERDATA,  'Thumbnails')
HOME             = xbmc.translatePath('special://home/')
LOG              = xbmc.translatePath('special://logpath/')
ADDONS           = os.path.join(HOME,      'addons')
PLUGIN           = os.path.join(ADDONS,    ADDON_ID)
DIALOG           = xbmcgui.Dialog()
DP               = xbmcgui.DialogProgress()
ART              = os.path.join(PLUGIN,    'resources', 'art')
FTG              = pyxbmct.AddonDialogWindow('')
MAINBG           = os.path.join(ART , 'main.jpg')
BUTTON           = os.path.join(ART , 'button.png')
LOGO             = os.path.join(ART , 'title.gif')
SpeedBG          = os.path.join(ART , 'speedtest.jpg')
BG               = os.path.join(ART , 'BG.png')
COLOR1           = 'blue'
COLOR2           = 'yellow'
COLOR3           = 'red'
COLOR4           = 'snow'
COLOR5           = 'lime'

DES_T_COLOR = 'blue'
DESCOLOR = 'orange'
BUTTONS_TEXT = 'yellow'

FOCUS_BUTTON_COLOR = 'lime'
FBUTTON  = os.path.join(ART , '%s.png' % FOCUS_BUTTON_COLOR) 


def clearCache():
	if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Clear Cache[/COLOR][/B]'):
		source.clearCache()
		DC.setLabel('[COLOR %s]Size:[/COLOR] [COLOR %s]0.0 B[/COLOR]' % (DES_T_COLOR, DESCOLOR))

def clearPackages():
	if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete Packages?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR green]Delete[/COLOR][/B]'):
		source.clearPackages('total')
		DPK.setLabel('[COLOR %s]Size:[/COLOR] [COLOR %s]0.0 B[/COLOR]' % (DES_T_COLOR, DESCOLOR))
		TPK.setLabel('[COLOR %s]Files:[/COLOR] [COLOR %s]0[/COLOR]' % (DES_T_COLOR, DESCOLOR))

def totalClean():
	if DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to clear cache, packages and thumbnails?[/COLOR]' % COLOR2, nolabel='[B][COLOR red]Cancel Process[/COLOR][/B]',yeslabel='[B][COLOR green]Clean All[/COLOR][/B]'):
		source.clearCache()
		source.clearPackages('total')
		clearThumb('total')
		TC.setLabel('[COLOR %s]Size:[/COLOR] [COLOR %s]0.0 B[/COLOR]' % (DES_T_COLOR, DESCOLOR))
		DC.setLabel('[COLOR %s]Size:[/COLOR] [COLOR %s]0.0 B[/COLOR]' % (DES_T_COLOR, DESCOLOR))
		DPK.setLabel('[COLOR %s]Size:[/COLOR] [COLOR %s]0.0 B[/COLOR]' % (DES_T_COLOR, DESCOLOR))
		TPK.setLabel('[COLOR %s]Files:[/COLOR] [COLOR %s]0[/COLOR]' % (DES_T_COLOR, DESCOLOR))
		DTH.setLabel('[COLOR %s]Size:[/COLOR] [COLOR %s]0.0 B[/COLOR]' % (DES_T_COLOR, DESCOLOR))
		TTH.setLabel('[COLOR %s]Files:[/COLOR] [COLOR %s]0[/COLOR]' % (DES_T_COLOR, DESCOLOR))
def clearThumb(type=None):
	latest = source.latestDB('Textures')
	if not type == None: choice = 1
	else: choice = DIALOG.yesno(ADDONTITLE, '[COLOR %s]Would you like to delete the %s and Thumbnails folder?' % (COLOR2, latest), "They will repopulate on the next startup[/COLOR]", nolabel='[B][COLOR red]Don\'t Delete[/COLOR][/B]', yeslabel='[B][COLOR green]Delete Thumbs[/COLOR][/B]')
	if choice == 1:
		try: source.removeFile(os.join(DATABASE, latest))
		except: source.log('Failed to delete, Purging DB.'); source.purgeDb(latest)
		source.removeFolder(THUMBS)
		DTH.setLabel('[COLOR %s]Size:[/COLOR] [COLOR %s]0.0 B[/COLOR]' % (DES_T_COLOR, DESCOLOR))
		TTH.setLabel('[COLOR %s]Files:[/COLOR] [COLOR %s]0[/COLOR]' % (DES_T_COLOR, DESCOLOR))
	else: source.log('Clear thumbnames cancelled')
	source.redoThumbs()
def runspeedtest():
	speed = speedtest.speedtest()
	speedthumb.setImage(speed[0])

ACTION_PREVIOUS_MENU 			=  10
ACTION_NAV_BACK 				=  92
ACTION_MOVE_LEFT				=   1
ACTION_MOVE_RIGHT 				=   2
ACTION_MOVE_UP 					=   3
ACTION_MOVE_DOWN 				=   4
ACTION_MOUSE_WHEEL_UP 			= 104
ACTION_MOUSE_WHEEL_DOWN			= 105
ACTION_MOVE_MOUSE 				= 107
ACTION_SELECT_ITEM				=   7
ACTION_BACKSPACE				= 110
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108

FTG.setGeometry(800, 600, 100, 50)
fan=pyxbmct.Image(MAINBG)
FTG.placeControl(fan, -10, -6, 125, 62)

sizepack   = source.getSize(PACKAGES)
totalpack   = source.getTotal(PACKAGES)
sizethumb  = source.getSize(THUMBS)
totalthumb   = source.getTotal(THUMBS)
sizecache  = source.getCacheSize()
totalsize  = sizepack+sizethumb+sizecache

logo = pyxbmct.Image(LOGO)
FTG.placeControl(logo, -7, 7, 35, 35)

sizebg = pyxbmct.Image(BG)
FTG.placeControl(sizebg, 22, -5, 30, 60)

store = pyxbmct.Image(BG)
FTG.placeControl(store, 70, 22, 41, 32)

buttons = pyxbmct.Image(BG)
FTG.placeControl(buttons, 50, -5, 21, 60)

speedthumb = pyxbmct.Image(SpeedBG)
FTG.placeControl(speedthumb, 70, -4, 40, 27)

TC = pyxbmct.Label('[COLOR %s]Size:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,source.convertSize(totalsize)))
FTG.placeControl(TC, 33 , -3 , 10, 14)

DC = pyxbmct.Label('[COLOR %s]Size:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,source.convertSize(sizecache)))
FTG.placeControl(DC, 33 , 11 , 10, 14)

DPK = pyxbmct.Label('[COLOR %s]Size:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,source.convertSize(sizepack)))
FTG.placeControl(DPK, 33 , 25 , 10, 14)

TPK = pyxbmct.Label('[COLOR %s]Files:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,totalpack))
FTG.placeControl(TPK, 40 , 25 ,  10, 14)

DTH = pyxbmct.Label('[COLOR %s]Size:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,source.convertSize(sizethumb)))
FTG.placeControl(DTH, 33 , 39 ,  10, 14)

TTH = pyxbmct.Label('[COLOR %s]Files:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR,totalthumb))
FTG.placeControl(TTH, 40 , 39 ,  10, 14)

total_clean_button = pyxbmct.Button('[COLOR %s]Total Clean Up[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(total_clean_button, 25 , -3 , 10, 14)
FTG.connect(total_clean_button,lambda: totalClean())

total_cache_button = pyxbmct.Button('[COLOR %s]Delete Cache[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(total_cache_button, 25 , 11 , 10, 14)
FTG.connect(total_cache_button,lambda: clearCache())

total_packages_button = pyxbmct.Button('[COLOR %s]Delete Packages[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(total_packages_button, 25 , 25 , 10, 14)
FTG.connect(total_packages_button,lambda: clearPackages())

total_thumbnails_button = pyxbmct.Button('[COLOR %s]Delete Thumbnails[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(total_thumbnails_button, 25 , 39 , 10, 14)
FTG.connect(total_thumbnails_button, lambda: clearThumb(type=None))

speedtest_button = pyxbmct.Button('[COLOR %s]Speed Test[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(speedtest_button, 55 , -1 , 10, 12)
FTG.connect(speedtest_button, lambda: runspeedtest())

showip_button = pyxbmct.Button('[COLOR %s]Show IPs[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(showip_button, 55 , 12 , 10, 12)
FTG.connect(showip_button, lambda: windows.SHOWNET())

advan_button = pyxbmct.Button('[COLOR %s]Advanced Settings[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(advan_button, 55 , 25 , 10, 12)
FTG.connect(advan_button, lambda: windows.autoConfig())

forceupdate_button = pyxbmct.Button('[COLOR %s]Update Addons[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(forceupdate_button, 55 , 38 , 10, 12)
FTG.connect(forceupdate_button,lambda: source.forceUpdate())

Log_errors = pyxbmct.Label('[COLOR %s]Log Errors:[/COLOR] %s' % (DES_T_COLOR, source.log_tools()))
FTG.placeControl(Log_errors,  75 , 40 , 10, 15)

view_error_button = pyxbmct.Button('[COLOR %s]View Errors[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(view_error_button, 85 , 40 , 10, 12)
FTG.connect(view_error_button,lambda: source.errorChecking(log=None, count=None, last=None))

full_log__button = pyxbmct.Button('[COLOR %s]Full Log[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(full_log__button, 95 , 40 , 10, 12)
FTG.connect(full_log__button,lambda: source.LogViewer())

settings_button1 = pyxbmct.Button('[COLOR %s]Settings[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(settings_button1, 4 , -3 ,  10, 10)
FTG.connect(settings_button1, lambda: source.openS('Maintenance'))

CloseButton = pyxbmct.Button('[COLOR %s]Close[/COLOR]' % BUTTONS_TEXT,focusTexture=FBUTTON,noFocusTexture=BUTTON)
FTG.placeControl(CloseButton, 4 , 43 ,10 , 10)
FTG.connect(CloseButton, FTG.close)

storage_free ,storage_used, storage_total, ram_free, ram_used, ram_total = source.SYSINFO()

store = pyxbmct.Label('[B][COLOR %s]Storage:[/COLOR][/B]'% DESCOLOR)
FTG.placeControl(store, 72, 25, 10, 15)

rom_used=pyxbmct.Label('[COLOR %s]Used:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR, storage_used))
FTG.placeControl(rom_used, 80, 25, 10, 15)

rom_free=pyxbmct.Label('[COLOR %s]Free:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR, storage_free))
FTG.placeControl(rom_free, 88, 25, 10, 15)

rom_total=pyxbmct.Label('[COLOR %s]Total:[/COLOR] [COLOR %s]%s[/COLOR]' % (DES_T_COLOR, DESCOLOR, storage_total))
FTG.placeControl(rom_total, 96, 25, 10, 15)

settings_button1.controlDown(total_clean_button)
settings_button1.controlRight(CloseButton)

CloseButton.controlLeft(settings_button1)
CloseButton.controlDown(total_thumbnails_button)

total_clean_button.controlUp(settings_button1)
total_clean_button.controlDown(speedtest_button)
total_clean_button.controlRight(total_cache_button)

total_cache_button.controlUp(settings_button1)
total_cache_button.controlLeft(total_clean_button)
total_cache_button.controlDown(showip_button)
total_cache_button.controlRight(total_packages_button)

total_packages_button.controlUp(CloseButton)
total_packages_button.controlLeft(total_cache_button)
total_packages_button.controlDown(advan_button)
total_packages_button.controlRight(total_thumbnails_button)

total_thumbnails_button.controlUp(CloseButton)
total_thumbnails_button.controlLeft(total_packages_button)
total_thumbnails_button.controlDown(forceupdate_button)

speedtest_button.controlUp(total_clean_button)
speedtest_button.controlDown(view_error_button)
speedtest_button.controlRight(showip_button)

showip_button.controlUp(total_cache_button)
showip_button.controlLeft(speedtest_button)
showip_button.controlDown(view_error_button)
showip_button.controlRight(advan_button)

advan_button.controlUp(total_packages_button)
advan_button.controlLeft(showip_button)
advan_button.controlDown(view_error_button)
advan_button.controlRight(forceupdate_button)

forceupdate_button.controlUp(total_thumbnails_button)
forceupdate_button.controlLeft(advan_button)
forceupdate_button.controlDown(view_error_button)

view_error_button.controlUp(forceupdate_button)
view_error_button.controlDown(full_log__button)

full_log__button.controlUp(view_error_button)

FTG.setFocus(settings_button1)

FTG.connect(pyxbmct.ACTION_NAV_BACK, FTG.close)
FTG.doModal()
del FTG 