############################################################################
#                             /T /I                                        #
#                              / |/ | .-~/                                 #
#                          T\ Y  I  |/  /  _                               #
#         /T               | \I  |  I  Y.-~/                               #
#        I l   /I       T\ |  |  l  |  T  /                                #
#     T\ |  \ Y l  /T   | \I  l   \ `  l Y                                 #
# __  | \l   \l  \I l __l  l   \   `  _. |                                 #
# \ ~-l  `\   `\  \  \ ~\  \   `. .-~   |                                  #
#  \   ~-. "-.  `  \  ^._ ^. "-.  /  \   |                                 #
#.--~-._  ~-  `  _  ~-_.-"-." ._ /._ ." ./                                 #
# >--.  ~-.   ._  ~>-"    "\   7   7   ]                                   #
#^.___~"--._    ~-{  .-~ .  `\ Y . /    |                                  #
# <__ ~"-.  ~       /_/   \   \I  Y   : |                                  #
#   ^-.__           ~(_/   \   >._:   | l______                            #
#       ^--.,___.-~"  /_/   !  `-.~"--l_ /     ~"-.                        #
#              (_/ .  ~(   /'     "~"--,Y   -=b-. _)                       #
#               (_/ .  \  Fire TV Guru/ l      c"~o \                      #
#                \ /    `.    .     .^   \_.-~"~--.  )                     #
#                 (_/ .   `  /     /       !       )/                      #
#                  / / _.   '.   .':      /        '                       #
#                  ~(_/ .   /    _  `  .-<_                                #
#                    /_/ . ' .-~" `.  / \  \          ,z=.                 #
#                    ~( /   '  :   | K   "-.~-.______//                    #
#                      "-,.    l   I/ \_    __{--->._(==.                  #
#                       //(     \  <    ~"~"     //                        #
#                      /' /\     \  \     ,v=.  ((                         #
#                    .^. / /\     "  }__ //===-  `                         #
#                   / / ' '  "-.,__ {---(==-                               #
#                 .^ '       :  T  ~"   ll                                 #
#                / .  .  . : | :!        \                                 #
#               (_/  /   | | j-"          ~^                               #
#                 ~-<_(_.^-~"                                              #
#                                                                          #
#   Copyright (C) 2018 FTG                                                 #
#                                                                          #
#   This program is free software: you can redistribute it and/or modify   #
#   it under the terms of the GNU General Public License as published by   #
#   the Free Software Foundation, either version 3 of the License, or      #
#   (at your option) any later version.                                    #
#                                                                          #
#   This program is distributed in the hope that it will be useful,        #
#   but WITHOUT ANY WARRANTY; without even the implied warranty of         #
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          #
#   GNU General Public License for more details.                           #
#                                                                          #
############################################################################

import urllib,urllib2,re,xbmcplugin,binascii,xbmcgui,sys,os,xbmcaddon,time,subprocess,urlparse
from resources.modules.addon import Addon
from resources.modules import extract
from resources.modules import downloader

addon_id = 'plugin.program.romgetter'
settings = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
mode = addon.queries['mode']
url = addon.queries.get('url', '')
name = addon.queries.get('name', '')
console = addon.queries.get('console', '')
thumb = addon.queries.get('thumb', '')
handle=int(sys.argv[1])
download_path = settings.getSetting('dl_path')
unzip = settings.getSetting('unzip')
setSetting = xbmcaddon.Addon().setSetting
base = 'http://www.doperoms.com'
baseS = 'https://www.doperoms.com'
ROMLOC           = xbmc.translatePath(os.path.join('//storage//emulated//0//roms',''))
WROMLOC          = xbmc.translatePath(os.path.join('C:\\roms\\',''))

def categories():
	MKDIRS()
	addDir('Addon Settings','None','settings','','none')
	addDir('-------------------------------------','None','','','none')
	addDir('3do Roms = 196',base+'/roms/3do.html', 'letterIndex', '3do', '' )
	addDir('Amiga Roms = 1,486',base+'/roms/Amiga.html', 'letterIndex', 'Amiga', '' )
	addDir('Amiga Cd32 Roms = 46', base+'/roms/Amiga_Cd32.html', 'letterIndex', 'Amiga_Cd32', '' )
	addDir('Amstrad Cpc Roms = 10,081',base+'/roms/Amstrad_Cpc.html', 'letterIndex', 'Amstrad_Cpc', '' )
	addDir('Apple Ii Roms = 3,773',base+'/roms/Apple_Ii.html', 'letterIndex', 'Apple_Ii', '' )
	addDir('Atari 2600 Roms = 2,687',base+'/roms/Atari_2600.html', 'letterIndex', 'Atari_2600', '' )
	addDir('Atari 5200 Roms = 282',base+'/roms/Atari_5200.html', 'letterIndex', 'Atari_5200', '' )
	addDir('Atari 7800 Roms = 183',base+'/roms/Atari_7800.html', 'letterIndex', 'Atari_7800', '' )
	addDir('Atari 8-bit Roms = 3,220',base+'/roms/Atari_8-bit.html', 'letterIndex', 'Atari_8-bit', '' )
	addDir('Atari 800 Roms = 6,198',base+'/roms/Atari_800.html', 'letterIndex', 'Atari_800', '' )
	addDir('Atari Jaguar Roms = 139',base+'/roms/Atari_Jaguar.html', 'letterIndex', 'Atari_Jaguar', '' )
	addDir('Atari Jaguar Cd Roms = 78',base+'/roms/Atari_Jaguar_Cd.html', 'letterIndex', 'Atari_Jaguar_Cd', '' )
	addDir('Atari Lynx Roms = 336',base+'/roms/Atari_Lynx.html', 'letterIndex', 'Atari_Lynx', '' )
	addDir('Atari St Roms = 6,123',base+'/roms/Atari_St.html', 'letterIndex', 'Atari_St', '' )
	addDir('Colecovision Roms = 303',base+'/roms/Colecovision.html', 'letterIndex', 'Colecovision', '' )
	addDir('Commodore 64 Roms = 6,886',base+'/roms/Commodore_64.html', 'letterIndex', 'Commodore_64', '' )
	addDir('Cps1 Cps2 Roms = 46',base+'/roms/Cps1_Cps2.html', 'letterIndex', 'Cps1_Cps2', '' )
	addDir('Dos Roms = 3,598',base+'/roms/Dos.html', 'letterIndex', 'Dos', '' )
	addDir('Famicom Disk Roms = 230',base+'/roms/Famicom_Disk.html', 'letterIndex', 'Famicom_Disk', '' )
	addDir('Gameboy Advance Gba Roms = 2,233',base+'/roms/Gameboy_Advance_Gba.html', 'letterIndex', 'Gameboy_Advance_Gba', '' )
	addDir('Gameboy And Gbc Roms = 2,653',base+'/roms/Gameboy_And_Gbc.html', 'letterIndex', 'Gameboy_And_Gbc', '' )
	addDir('Mac Roms = 815',base+'/roms/Mac.html', 'letterIndex', 'Mac', '' )
	addDir('Magnavox Odyssey Roms = 94',base+'/roms/Magnavox_Odyssey.html', 'letterIndex', 'Magnavox_Odyssey', '' )
	addDir('Mame Roms = 26,224',base+'/roms/Mame.html', 'letterIndex', 'Mame', '' )
	addDir('Mame Chd Roms = 360',base+'/roms/Mame_Chd.html', 'letterIndex', 'Mame_Chd', '' )
	addDir('Msx 1 Roms = 589',base+'/roms/Msx_1.html', 'letterIndex', 'Msx_1', '' )
	addDir('Msx 2 Roms = 166',base+'/roms/Msx_2.html', 'letterIndex', 'Msx_2', '' )
	addDir('Neo Geo Roms = 583',base+'/roms/Neo_Geo.html', 'letterIndex', 'Neo_Geo', '' )
	addDir('Neo Geo Cd Roms = 97',base+'/roms/Neo_Geo_Cd.html', 'letterIndex', 'Neo_Geo_Cd', '' )
	addDir('Neo Geo Pocket Roms = 277',base+'/roms/Neo_Geo_Pocket.html', 'letterIndex', 'Neo_Geo_Pocket', '' )
	addDir('Nintendo 64 Roms = 2,107',base+'/roms/Nintendo_64.html', 'letterIndex', 'Nintendo_64', '' )
	addDir('Nintendo Ds Roms = 516',base+'/roms/Nintendo_Ds.html', 'letterIndex', 'Nintendo_Ds', '' )
	addDir('Nintendo Gamecube Roms = 541',base+'/roms/Nintendo_Gamecube.html', 'letterIndex', 'Nintendo_Gamecube', '' )
	addDir('Nintendo Nes Roms = 9,240',base+'/roms/Nintendo_Nes.html', 'letterIndex', 'Nintendo_Nes', '' )
	addDir('Super Nintendo Snes Roms = 10,450',base+'/roms/Super_Nintendo_Snes.html', 'letterIndex', 'Super_Nintendo_Snes', '' )
	addDir('Nokia N-gage Roms = 127',base+'/roms/Nokia_N-gage.html', 'letterIndex', 'Nokia_N-gage', '' )
	addDir('Scummvm Roms = 187',base+'/roms/Scummvm.html', 'letterIndex', 'Scummvm', '' )
	addDir('Sega Cd Roms = 315',base+'/roms/Sega_Cd.html', 'letterIndex', 'Sega_Cd', '' )
	addDir('Sega Dreamcast Roms = 897',base+'/roms/Sega_Dreamcast.html', 'letterIndex', 'Sega_Dreamcast', '' )
	addDir('Sega Game Gear Roms = 665',base+'/roms/Sega_Game_Gear.html', 'letterIndex', 'Sega_Game_Gear', '' )
	addDir('Sega Genesis 32x Roms = 58',base+'/roms/32x.html', 'letterIndex', 'Sega_Genesis_32x', '' )
	addDir('Sega Genesis Roms = 5,462',base+'/roms/Sega_Genesis.html', 'letterIndex', 'Sega_Genesis', '' )
	addDir('Sega Master System Roms = 1,430',base+'/roms/Sega_Master_System.html', 'letterIndex', 'Sega_Master_System', '' )
	addDir('Sega Model 2 Roms = 8',base+'/roms/Sega_Model_2.html', 'letterIndex', 'Sega_Model_2', '' )
	addDir('Sega Saturn Roms = 291',base+'/roms/Sega_Saturn.html', 'letterIndex', 'Sega_Saturn', '' )
	addDir('Sega Sg-1000 Roms = 60',base+'/roms/Sega_Sg-1000.html', 'letterIndex', 'Sega_Sg-1000', '' )
	addDir('Sharp X68000 Roms = 940',base+'/roms/Sharp_X68000.html', 'letterIndex', 'Sharp_X68000', '' )
	addDir('Sinclair Zx Spectrum Roms = 38,184',base+'/roms/Sinclair_Zx_Spectrum.html', 'letterIndex', 'Sinclair_Zx_Spectrum', '' )
	addDir('Sony Playstation Psx Roms = 904',base+'/roms/Sony_Playstation_Psx.html', 'letterIndex', 'Sony_Playstation_Psx', '' )
	addDir('Sony Pocketstation Roms = 110',base+'/roms/Sony_Pocketstation.html', 'letterIndex', 'Sony_Pocketstation', '' )
	addDir('Sony Psp Roms = 60',base+'/roms/Sony_Psp.html', 'letterIndex', 'Sony_Psp', '' )
	addDir('Turbografx 16 Roms = 1,579',base+'/roms/Turbografx_16.html', 'letterIndex', 'Turbografx_16', '' )
	addDir('Turbografx 16 Cd Roms = 177',base+'/roms/Turbografx_16_Cd.html', 'letterIndex', 'Turbografx_16_Cd', '' )
	addDir('Vectrex Roms = 287',base+'/roms/Vectrex.html', 'letterIndex', 'Vectrex', '' )
	addDir('Virtual Boy Roms = 60',base+'/roms/Virtual_Boy.html', 'letterIndex', 'Virtual_Boy', '' )
	addDir('Wonderswan Roms = 279',base+'/roms/Wonderswan.html', 'letterIndex', 'Wonderswan', '' )
	addDir('Zinc Roms = 87',base+'/roms/Zinc.html', 'letterIndex', 'Zinc', '' )
	xbmcplugin.endOfDirectory(handle)
	
def settings():
	addon.show_settings()
	return
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def getURL(url):
	
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def openURL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0')
	xbmc.log('REQ -: %s' % (req),xbmc.LOGNOTICE)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def letterIndex(url):
	http = getURL(url)
	be= http.find('<table border="0" width="100%" cellpadding="0" cellspacing="0">')
	en= http.find('<h1>')
	http=http[be:en]
	match=re.compile('<a id="listing" href="(.+?)">(.+?)</a>').findall(http)
	for url,name in match:
		if name == '#':
			url = url.replace(url[-5:], '/0.html')
			addDir(name,base+url,'romIndex',console,'')
		else:
			url = url.replace(url[-5:], '/0.html')
			addDir(name,base+url,'romIndex',console,'')	

def romIndex(url):
	pagenum = url.split('/')
	curpage = int(pagenum[6].replace('.html',''))
	nextpage = curpage + 50
	nextpageurl = base+'/'+console+'/'+pagenum[5]+'/'+str(nextpage)+'.html'
	http = getURL(url)
	be = http.find('<td height="40" align="left" valign="middle">')
	en = http.find('</table><BR><BR><BR><BR>')
	http =http[be:en]
	match = re.compile('<a id="listing" href="(.+?)" name="(.+?)"').findall(http)
	for url,name in match:
		if '.zip' or '.ZIP' in name:
				addDir(name,baseS+url,'download',console,'')
	try:
		addDir('[I][B][COLOR yellow]Next Page >>>[/COLOR][/B][/I]',nextpageurl,'romIndex',console,'')
	except:pass
	xbmcplugin.endOfDirectory(handle)
	
def download(url):
	url = url.replace(' ','%20')
	http = openURL(url)
	be = http.find('<div style="padding-left:40px;">')
	en = http.find('<img src="/download.gif"')
	http = http[be:en]
	match = re.compile('<a href="(.+?)">').findall(http)
	for url in match:
		url = url.replace(' ','%20')
		url2 = (baseS+url)
		http = getURL(url2)
		be = http.find('<div style="padding:15px; width: 400px; border:1px dashed #000000;">')
		en = http.find('<img src="/download.gif"')
		http = http[be:en]
		match2 = re.compile('<a href="(.+?)">').findall(http)
		for url in match2:
			url = url.replace(' ','%20')
			url3 = (baseS+url)
			dialog = xbmcgui.Dialog()    
			http = getURL(url3)
			direct = download_path + console
			if not os.path.exists(direct):
					os.makedirs(direct)
			dp = xbmcgui.DialogProgress()
			lib=os.path.join(direct,name)
			dp.create("FTG Rom Downloader","Downloading ",'', 'Please Wait')		
			downloader.download(url3, lib, dp)
			if unzip == 'true':
				time.sleep(2)
				dp.update(0,"", "Extracting Rom, Please Wait")
				extract.all(lib,direct,dp)
				print '======================================='
				print direct
				print '======================================='
				os.remove(lib)
				dp.close()
				dialog.ok('FTG Rom Downloader','Download completed...', 'Rom located at %s' % direct)
			else:
				dp.close()
				dialog.ok('FTG Rom Downloader','Download completed...', 'Rom located at %s' % direct)
				
			return
		return

def Nxtpage(url):
	http = getURL(url)
	be = http.find('</div><br/><br/><div style="padding:15px')
	en = http.find('<SCRIPT language="Javascript">')
	http = http[be:en]
	match = re.compile('<a href="(.+?)"><img src="').findall(http)
	for url in match:
		Dload(base+url)

def Dload(url, dp = None):
	dialog = xbmcgui.Dialog()    
	http = getURL(url)
	direct = download_path + console
	if not os.path.exists(direct):
			os.makedirs(direct)
	dp = xbmcgui.DialogProgress()
	lib=os.path.join(direct,name)
	dp.create("FTG Rom Downloader","Downloading ",'', 'Please Wait')		
	downloader.download(url, lib, dp)
	dialog.ok('FTG Rom Downloader','Download completed...', 'Rom located at %s' % download_path)
	return

def addDir(name,url,mode,console,thumb):
	params = {'url':url, 'mode':mode, 'name':name, 'console':console, 'thumb':thumb}
	addon.add_directory(params, {'title':name}, context_replace=True, img=thumb)

def MKDIRS():
	if xbmc.getCondVisibility('system.platform.android'):
		if download_path == '':
			if not os.path.exists(ROMLOC): os.makedirs(ROMLOC)
			setSetting('dl_path',ROMLOC)
	elif xbmc.getCondVisibility('system.platform.windows'):
		if download_path == '':
			if not os.path.exists(WROMLOC): os.makedirs(WROMLOC)
			setSetting('dl_path',WROMLOC)

if mode==None or url==None or len(url)<1:categories()
if mode=='letterIndex':letterIndex(url)
if mode=='romIndex':romIndex(url)
if mode=='download':download(url)	
if mode=='Dload':Dload(url)
if mode=='settings':settings()
if mode=='Retroarch':Retroarch()
xbmcplugin.endOfDirectory(int(sys.argv[1]))
